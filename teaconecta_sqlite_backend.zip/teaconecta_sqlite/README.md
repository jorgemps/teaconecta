# Guia de Instalação e Uso do TEAconecta (Versão SQLite)

Este guia contém instruções detalhadas para instalar e executar o backend do TEAconecta usando SQLite, uma solução de banco de dados que não requer instalação de servidor separado.

## Requisitos

- Node.js (versão 14 ou superior)
- NPM (geralmente instalado com o Node.js)
- Navegador web moderno (Chrome, Firefox, Edge, Safari)

## Instalação

1. **Extraia o arquivo ZIP** em uma pasta de sua escolha
   ```
   C:\Users\SeuUsuario\Documents\teaconecta_sqlite
   ```

2. **Abra o Prompt de Comando** como administrador

3. **Navegue até a pasta do projeto**
   ```
   cd C:\Users\SeuUsuario\Documents\teaconecta_sqlite
   ```

4. **Instale as dependências**
   ```
   npm install
   ```
   Este comando instalará todas as bibliotecas necessárias para o funcionamento do backend.

## Executando o Backend

1. **Inicie o servidor**
   ```
   npm start
   ```

2. **Verifique se o servidor está rodando**
   - Abra seu navegador
   - Acesse: http://localhost:3000/api/status
   - Você deverá ver uma mensagem de confirmação em formato JSON

## Estrutura do Projeto

```
teaconecta_sqlite/
├── database/
│   ├── schema.sql       # Definição das tabelas
│   └── teaconecta.db    # Banco de dados SQLite (criado automaticamente)
├── src/
│   ├── config/          # Configurações
│   ├── controllers/     # Controladores da API
│   ├── middlewares/     # Middlewares
│   ├── routes/          # Rotas da API
│   ├── scripts/         # Scripts de inicialização
│   ├── utils/           # Utilitários
│   ├── app.js           # Configuração do Express
│   └── server.js        # Ponto de entrada
├── .env                 # Variáveis de ambiente
├── package.json         # Dependências e scripts
└── README.md            # Este arquivo
```

## Usuário Administrador Padrão

Ao iniciar o servidor pela primeira vez, um usuário administrador padrão é criado automaticamente:

- **Email**: admin@teaconecta.com
- **Senha**: admin123

Recomendamos alterar esta senha após o primeiro login.

## Endpoints da API

### Autenticação

- **Registro de usuário**
  ```
  POST /api/auth/register
  ```
  Corpo da requisição:
  ```json
  {
    "nome": "Nome Completo",
    "email": "email@exemplo.com",
    "senha": "senha123",
    "telefone": "(00) 00000-0000",
    "tipo_perfil": "PROFISSIONAL"
  }
  ```

- **Login**
  ```
  POST /api/auth/login
  ```
  Corpo da requisição:
  ```json
  {
    "email": "email@exemplo.com",
    "senha": "senha123"
  }
  ```
  Resposta:
  ```json
  {
    "status": "success",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": 1,
      "nome": "Nome Completo",
      "email": "email@exemplo.com",
      "tipo_perfil": "PROFISSIONAL"
    }
  }
  ```

- **Obter perfil do usuário logado**
  ```
  GET /api/auth/profile
  ```
  Cabeçalho:
  ```
  Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
  ```

### Usuários

- **Listar usuários**
  ```
  GET /api/users
  ```

- **Obter detalhes de um usuário**
  ```
  GET /api/users/:id
  ```

- **Atualizar usuário**
  ```
  PUT /api/users/:id
  ```
  Corpo da requisição:
  ```json
  {
    "nome": "Novo Nome",
    "telefone": "(00) 99999-9999",
    "dados_perfil": {
      "especialidade": "Fonoaudiologia",
      "biografia": "Profissional com 10 anos de experiência..."
    }
  }
  ```

### Atividades

- **Listar atividades**
  ```
  GET /api/activities
  ```

- **Obter detalhes de uma atividade**
  ```
  GET /api/activities/:id
  ```

- **Criar nova atividade**
  ```
  POST /api/activities
  ```
  Corpo da requisição:
  ```json
  {
    "titulo": "Exercício de comunicação",
    "descricao": "Praticar identificação de emoções através de imagens",
    "paciente_id": 3,
    "data_inicio": "2025-05-25",
    "data_fim": "2025-05-30",
    "recursos": ["Cartões de emoções", "Tablet"],
    "instrucoes": "Mostrar os cartões e pedir para identificar as emoções"
  }
  ```

- **Atualizar atividade**
  ```
  PUT /api/activities/:id
  ```

- **Atualizar feedback do paciente**
  ```
  PATCH /api/activities/:id/feedback
  ```
  Corpo da requisição:
  ```json
  {
    "feedback_paciente": "Consegui identificar 8 de 10 emoções",
    "dificuldade": "media"
  }
  ```

### Comunicações

- **Listar comunicações**
  ```
  GET /api/communications
  ```

- **Obter detalhes de uma comunicação**
  ```
  GET /api/communications/:id
  ```

- **Enviar nova comunicação**
  ```
  POST /api/communications
  ```
  Corpo da requisição:
  ```json
  {
    "destinatario_id": 3,
    "assunto": "Feedback da sessão de hoje",
    "conteudo": "Gostaria de compartilhar algumas observações sobre a sessão de hoje...",
    "anexos": [
      {
        "nome": "relatorio.pdf",
        "url": "data:application/pdf;base64,JVBERi0xLjMKJcTl8uXrp..."
      }
    ]
  }
  ```

- **Atualizar status da comunicação**
  ```
  PATCH /api/communications/:id/status
  ```
  Corpo da requisição:
  ```json
  {
    "status": "lida"
  }
  ```

## Testando a API

Você pode testar a API usando ferramentas como:

1. **Postman**: https://www.postman.com/downloads/
2. **Insomnia**: https://insomnia.rest/download
3. **Thunder Client**: Extensão para VS Code

## Integração com o Frontend

Para integrar o backend com o frontend do TEAconecta:

1. Certifique-se de que o backend está rodando na porta 3000
2. Configure o frontend para acessar a API em `http://localhost:3000/api`
3. Use o token JWT retornado no login para autenticar as requisições

Exemplo de código para integração no frontend:

```javascript
// Função de login
async function login(email, senha) {
  try {
    const response = await fetch('http://localhost:3000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, senha })
    });
    
    const data = await response.json();
    
    if (data.status === 'success') {
      // Salvar token no localStorage
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      return data.user;
    } else {
      throw new Error(data.message || 'Erro ao fazer login');
    }
  } catch (error) {
    console.error('Erro no login:', error);
    throw error;
  }
}

// Função para fazer requisições autenticadas
async function fetchAutenticado(url, options = {}) {
  const token = localStorage.getItem('token');
  
  if (!token) {
    throw new Error('Usuário não autenticado');
  }
  
  const headers = {
    ...options.headers,
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };
  
  const response = await fetch(`http://localhost:3000/api${url}`, {
    ...options,
    headers
  });
  
  const data = await response.json();
  
  if (response.status === 401) {
    // Token expirado ou inválido
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
    throw new Error('Sessão expirada');
  }
  
  return data;
}
```

## Solução de Problemas

### Erro ao iniciar o servidor

Se você encontrar erros ao iniciar o servidor, verifique:

1. **Node.js está instalado corretamente**
   ```
   node --version
   ```
   Deve mostrar v14.0.0 ou superior

2. **Dependências foram instaladas**
   ```
   npm install
   ```

3. **Porta 3000 está disponível**
   Se outro programa estiver usando a porta 3000, você pode alterar a porta no arquivo `.env`:
   ```
   PORT=3001
   ```

### Erro de autenticação

Se você encontrar erros de autenticação:

1. **Verifique se o token JWT está sendo enviado corretamente**
   O token deve ser enviado no cabeçalho Authorization como "Bearer [token]"

2. **Verifique se o token não expirou**
   Os tokens têm validade de 24 horas por padrão

## Suporte

Para obter suporte adicional, entre em contato com a equipe do TEAconecta através do email suporte@teaconecta.com.

---

Desenvolvido por TEAconecta © 2025
