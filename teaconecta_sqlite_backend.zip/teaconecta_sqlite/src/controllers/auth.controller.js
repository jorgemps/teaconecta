// Controlador de autenticação
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { run, get, all } = require('../config/db');
const { logger } = require('../utils/logger');
require('dotenv').config();

// Registrar novo usuário
const register = async (req, res) => {
  try {
    const {
      nome,
      email,
      senha,
      telefone,
      tipo_perfil,
      dados_perfil
    } = req.body;
    
    // Validar campos obrigatórios
    if (!nome || !email || !senha || !tipo_perfil) {
      return res.status(400).json({
        status: 'error',
        message: 'Campos obrigatórios não fornecidos'
      });
    }
    
    // Validar tipo de perfil
    const tiposValidos = ['CLINICA', 'PROFISSIONAL', 'PACIENTE'];
    if (!tiposValidos.includes(tipo_perfil)) {
      return res.status(400).json({
        status: 'error',
        message: 'Tipo de perfil inválido'
      });
    }
    
    // Verificar se o email já está em uso
    const userExists = await get('SELECT * FROM usuarios WHERE email = ?', [email]);
    
    if (userExists) {
      return res.status(400).json({
        status: 'error',
        message: 'Este email já está em uso'
      });
    }
    
    // Hash da senha
    const salt = await bcrypt.genSalt(10);
    const senhaHash = await bcrypt.hash(senha, salt);
    
    // Inserir usuário
    const result = await run(
      'INSERT INTO usuarios (nome, email, senha_hash, telefone, tipo_perfil) VALUES (?, ?, ?, ?, ?)',
      [nome, email, senhaHash, telefone || null, tipo_perfil]
    );
    
    const userId = result.lastID;
    
    // Criar perfil específico com base no tipo
    if (tipo_perfil === 'CLINICA') {
      // Extrair dados do perfil da clínica
      const {
        cnpj,
        razao_social,
        nome_fantasia,
        endereco_cep,
        endereco_logradouro,
        endereco_numero,
        endereco_complemento,
        endereco_bairro,
        endereco_cidade,
        endereco_estado,
        telefone_comercial,
        email_comercial,
        site
      } = dados_perfil || {};
      
      // Inserir perfil de clínica
      await run(
        `INSERT INTO perfis_clinicas (
          usuario_id, cnpj, razao_social, nome_fantasia, 
          endereco_cep, endereco_logradouro, endereco_numero, endereco_complemento, 
          endereco_bairro, endereco_cidade, endereco_estado, 
          telefone_comercial, email_comercial, site
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userId, cnpj || null, razao_social || null, nome_fantasia || null,
          endereco_cep || null, endereco_logradouro || null, endereco_numero || null, endereco_complemento || null,
          endereco_bairro || null, endereco_cidade || null, endereco_estado || null,
          telefone_comercial || null, email_comercial || null, site || null
        ]
      );
    } else if (tipo_perfil === 'PROFISSIONAL') {
      // Extrair dados do perfil do profissional
      const {
        registro_profissional,
        especialidade,
        formacao,
        biografia,
        foto_perfil,
        disponibilidade_inicio,
        disponibilidade_fim,
        dias_disponibilidade,
        valor_sessao,
        duracao_sessao
      } = dados_perfil || {};
      
      // Inserir perfil de profissional
      await run(
        `INSERT INTO perfis_profissionais (
          usuario_id, registro_profissional, especialidade, formacao, 
          biografia, foto_perfil, disponibilidade_inicio, disponibilidade_fim, 
          dias_disponibilidade, valor_sessao, duracao_sessao
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userId, registro_profissional || null, especialidade || null, formacao || null,
          biografia || null, foto_perfil || null, disponibilidade_inicio || null, disponibilidade_fim || null,
          dias_disponibilidade || null, valor_sessao || null, duracao_sessao || null
        ]
      );
    } else if (tipo_perfil === 'PACIENTE') {
      // Extrair dados do perfil do paciente
      const {
        data_nascimento,
        genero,
        diagnostico,
        nivel_suporte,
        observacoes,
        alergias,
        medicamentos,
        responsavel_nome,
        responsavel_telefone,
        responsavel_email,
        responsavel_parentesco
      } = dados_perfil || {};
      
      // Inserir perfil de paciente
      await run(
        `INSERT INTO perfis_pacientes (
          usuario_id, data_nascimento, genero, diagnostico, 
          nivel_suporte, observacoes, alergias, medicamentos, 
          responsavel_nome, responsavel_telefone, responsavel_email, responsavel_parentesco
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userId, data_nascimento || null, genero || null, diagnostico || null,
          nivel_suporte || null, observacoes || null, alergias || null, medicamentos || null,
          responsavel_nome || null, responsavel_telefone || null, responsavel_email || null, responsavel_parentesco || null
        ]
      );
    }
    
    // Resposta de sucesso
    return res.status(201).json({
      status: 'success',
      message: 'Usuário registrado com sucesso',
      data: {
        id: userId,
        nome,
        email,
        tipo_perfil
      }
    });
  } catch (error) {
    logger.error(`Erro ao registrar usuário: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao registrar usuário',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Login de usuário
const login = async (req, res) => {
  try {
    const { email, senha } = req.body;
    
    // Validar campos obrigatórios
    if (!email || !senha) {
      return res.status(400).json({
        status: 'error',
        message: 'Email e senha são obrigatórios'
      });
    }
    
    // Buscar usuário pelo email
    const user = await get('SELECT * FROM usuarios WHERE email = ?', [email]);
    
    if (!user) {
      return res.status(401).json({
        status: 'error',
        message: 'Credenciais inválidas'
      });
    }
    
    // Verificar se o usuário está ativo
    if (user.status !== 'ativo') {
      return res.status(401).json({
        status: 'error',
        message: 'Usuário inativo ou bloqueado'
      });
    }
    
    // Verificar senha
    const senhaCorreta = await bcrypt.compare(senha, user.senha_hash);
    
    if (!senhaCorreta) {
      return res.status(401).json({
        status: 'error',
        message: 'Credenciais inválidas'
      });
    }
    
    // Atualizar último acesso
    await run(
      'UPDATE usuarios SET ultimo_acesso = CURRENT_TIMESTAMP WHERE id = ?',
      [user.id]
    );
    
    // Gerar token JWT
    const token = jwt.sign(
      { 
        id: user.id,
        tipo_perfil: user.tipo_perfil
      },
      process.env.JWT_SECRET || 'teaconecta_secret_key',
      { 
        expiresIn: process.env.JWT_EXPIRATION || '24h' 
      }
    );
    
    // Registrar log de acesso
    await run(
      'INSERT INTO logs_acesso (usuario_id, acao, status, ip, dispositivo) VALUES (?, ?, ?, ?, ?)',
      [user.id, 'login', 'sucesso', req.ip || 'desconhecido', req.headers['user-agent'] || 'desconhecido']
    );
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Login realizado com sucesso',
      data: {
        token,
        user: {
          id: user.id,
          nome: user.nome,
          email: user.email,
          tipo_perfil: user.tipo_perfil
        }
      }
    });
  } catch (error) {
    logger.error(`Erro ao realizar login: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao realizar login',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Obter perfil do usuário
const getProfile = async (req, res) => {
  try {
    const userId = req.userId;
    
    // Buscar dados básicos do usuário
    const user = await get('SELECT id, nome, email, telefone, tipo_perfil, status, data_cadastro, ultimo_acesso FROM usuarios WHERE id = ?', [userId]);
    
    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'Usuário não encontrado'
      });
    }
    
    // Buscar dados específicos do perfil com base no tipo
    let profileData = {};
    
    if (user.tipo_perfil === 'CLINICA') {
      profileData = await get('SELECT * FROM perfis_clinicas WHERE usuario_id = ?', [userId]) || {};
    } else if (user.tipo_perfil === 'PROFISSIONAL') {
      profileData = await get('SELECT * FROM perfis_profissionais WHERE usuario_id = ?', [userId]) || {};
    } else if (user.tipo_perfil === 'PACIENTE') {
      profileData = await get('SELECT * FROM perfis_pacientes WHERE usuario_id = ?', [userId]) || {};
    }
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      data: {
        user,
        profile_data: profileData
      }
    });
  } catch (error) {
    logger.error(`Erro ao obter perfil: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao obter perfil',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Atualizar senha
const updatePassword = async (req, res) => {
  try {
    const userId = req.userId;
    const { senha_atual, nova_senha } = req.body;
    
    // Validar campos obrigatórios
    if (!senha_atual || !nova_senha) {
      return res.status(400).json({
        status: 'error',
        message: 'Senha atual e nova senha são obrigatórias'
      });
    }
    
    // Buscar usuário
    const user = await get('SELECT * FROM usuarios WHERE id = ?', [userId]);
    
    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'Usuário não encontrado'
      });
    }
    
    // Verificar senha atual
    const senhaCorreta = await bcrypt.compare(senha_atual, user.senha_hash);
    
    if (!senhaCorreta) {
      return res.status(401).json({
        status: 'error',
        message: 'Senha atual incorreta'
      });
    }
    
    // Hash da nova senha
    const salt = await bcrypt.genSalt(10);
    const novaSenhaHash = await bcrypt.hash(nova_senha, salt);
    
    // Atualizar senha
    await run(
      'UPDATE usuarios SET senha_hash = ? WHERE id = ?',
      [novaSenhaHash, userId]
    );
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Senha atualizada com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao atualizar senha: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao atualizar senha',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Logout
const logout = async (req, res) => {
  try {
    const userId = req.userId;
    
    // Registrar log de logout
    await run(
      'INSERT INTO logs_acesso (usuario_id, acao, status, ip, dispositivo) VALUES (?, ?, ?, ?, ?)',
      [userId, 'logout', 'sucesso', req.ip || 'desconhecido', req.headers['user-agent'] || 'desconhecido']
    );
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Logout realizado com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao realizar logout: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao realizar logout',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

module.exports = {
  register,
  login,
  getProfile,
  updatePassword,
  logout
};
