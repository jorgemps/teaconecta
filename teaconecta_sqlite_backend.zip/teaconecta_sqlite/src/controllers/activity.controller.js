// Controlador de atividades
const { run, get, all } = require('../config/db');
const { logger } = require('../utils/logger');

// Listar atividades
const listActivities = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { paciente_id, status, data_inicio, data_fim } = req.query;
    
    let query = '';
    let params = [];
    
    // Construir query com base no tipo de usuário
    if (userType === 'ADMIN') {
      // Administradores podem ver todas as atividades
      query = `
        SELECT a.*, 
               u_prof.nome as profissional_nome,
               u_pac.nome as paciente_nome
        FROM atividades a
        JOIN perfis_profissionais pp ON a.profissional_id = pp.id
        JOIN usuarios u_prof ON pp.usuario_id = u_prof.id
        JOIN perfis_pacientes pac ON a.paciente_id = pac.id
        JOIN usuarios u_pac ON pac.usuario_id = u_pac.id
        WHERE 1=1
      `;
    } else if (userType === 'PROFISSIONAL') {
      // Profissionais veem apenas suas atividades
      const profissionalPerfil = await get(
        'SELECT id FROM perfis_profissionais WHERE usuario_id = ?',
        [userId]
      );
      
      if (!profissionalPerfil) {
        return res.status(404).json({
          status: 'error',
          message: 'Perfil de profissional não encontrado'
        });
      }
      
      query = `
        SELECT a.*, 
               u_prof.nome as profissional_nome,
               u_pac.nome as paciente_nome
        FROM atividades a
        JOIN perfis_profissionais pp ON a.profissional_id = pp.id
        JOIN usuarios u_prof ON pp.usuario_id = u_prof.id
        JOIN perfis_pacientes pac ON a.paciente_id = pac.id
        JOIN usuarios u_pac ON pac.usuario_id = u_pac.id
        WHERE a.profissional_id = ?
      `;
      params.push(profissionalPerfil.id);
    } else if (userType === 'PACIENTE') {
      // Pacientes veem apenas suas atividades
      const pacientePerfil = await get(
        'SELECT id FROM perfis_pacientes WHERE usuario_id = ?',
        [userId]
      );
      
      if (!pacientePerfil) {
        return res.status(404).json({
          status: 'error',
          message: 'Perfil de paciente não encontrado'
        });
      }
      
      query = `
        SELECT a.*, 
               u_prof.nome as profissional_nome,
               u_pac.nome as paciente_nome
        FROM atividades a
        JOIN perfis_profissionais pp ON a.profissional_id = pp.id
        JOIN usuarios u_prof ON pp.usuario_id = u_prof.id
        JOIN perfis_pacientes pac ON a.paciente_id = pac.id
        JOIN usuarios u_pac ON pac.usuario_id = u_pac.id
        WHERE a.paciente_id = ?
      `;
      params.push(pacientePerfil.id);
    } else if (userType === 'CLINICA') {
      // Clínicas veem atividades de seus profissionais
      query = `
        SELECT a.*, 
               u_prof.nome as profissional_nome,
               u_pac.nome as paciente_nome
        FROM atividades a
        JOIN perfis_profissionais pp ON a.profissional_id = pp.id
        JOIN usuarios u_prof ON pp.usuario_id = u_prof.id
        JOIN perfis_pacientes pac ON a.paciente_id = pac.id
        JOIN usuarios u_pac ON pac.usuario_id = u_pac.id
        JOIN vinculos_clinica_profissional vcp ON pp.id = vcp.profissional_id
        JOIN perfis_clinicas pc ON vcp.clinica_id = pc.id
        WHERE pc.usuario_id = ?
      `;
      params.push(userId);
    }
    
    // Adicionar filtros opcionais
    if (paciente_id) {
      query += ' AND a.paciente_id = ?';
      params.push(paciente_id);
    }
    
    if (status) {
      query += ' AND a.status = ?';
      params.push(status);
    }
    
    if (data_inicio) {
      query += ' AND a.data_inicio >= ?';
      params.push(data_inicio);
    }
    
    if (data_fim) {
      query += ' AND a.data_fim <= ?';
      params.push(data_fim);
    }
    
    // Ordenar por data de criação (mais recentes primeiro)
    query += ' ORDER BY a.data_criacao DESC';
    
    // Executar a consulta
    const atividades = await all(query, params);
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      data: atividades
    });
  } catch (error) {
    logger.error(`Erro ao listar atividades: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao listar atividades',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Obter detalhes de uma atividade
const getActivity = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { id } = req.params;
    
    // Verificar se a atividade existe
    const atividade = await get(
      `SELECT a.*, 
              u_prof.nome as profissional_nome,
              u_pac.nome as paciente_nome
       FROM atividades a
       JOIN perfis_profissionais pp ON a.profissional_id = pp.id
       JOIN usuarios u_prof ON pp.usuario_id = u_prof.id
       JOIN perfis_pacientes pac ON a.paciente_id = pac.id
       JOIN usuarios u_pac ON pac.usuario_id = u_pac.id
       WHERE a.id = ?`,
      [id]
    );
    
    if (!atividade) {
      return res.status(404).json({
        status: 'error',
        message: 'Atividade não encontrada'
      });
    }
    
    // Verificar permissão de acesso
    let temPermissao = false;
    
    if (userType === 'ADMIN') {
      // Administradores podem ver todas as atividades
      temPermissao = true;
    } else if (userType === 'PROFISSIONAL') {
      // Profissionais veem apenas suas atividades
      const profissionalPerfil = await get(
        'SELECT id FROM perfis_profissionais WHERE usuario_id = ?',
        [userId]
      );
      
      temPermissao = profissionalPerfil && profissionalPerfil.id === atividade.profissional_id;
    } else if (userType === 'PACIENTE') {
      // Pacientes veem apenas suas atividades
      const pacientePerfil = await get(
        'SELECT id FROM perfis_pacientes WHERE usuario_id = ?',
        [userId]
      );
      
      temPermissao = pacientePerfil && pacientePerfil.id === atividade.paciente_id;
    } else if (userType === 'CLINICA') {
      // Clínicas veem atividades de seus profissionais
      const clinicaProfissional = await get(
        `SELECT vcp.id 
         FROM vinculos_clinica_profissional vcp
         JOIN perfis_clinicas pc ON vcp.clinica_id = pc.id
         WHERE pc.usuario_id = ? AND vcp.profissional_id = ?`,
        [userId, atividade.profissional_id]
      );
      
      temPermissao = !!clinicaProfissional;
    }
    
    if (!temPermissao) {
      return res.status(403).json({
        status: 'error',
        message: 'Acesso não autorizado a esta atividade'
      });
    }
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      data: atividade
    });
  } catch (error) {
    logger.error(`Erro ao obter detalhes da atividade: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao obter detalhes da atividade',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Criar nova atividade
const createActivity = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    
    // Apenas profissionais podem criar atividades
    if (userType !== 'PROFISSIONAL' && userType !== 'ADMIN') {
      return res.status(403).json({
        status: 'error',
        message: 'Apenas profissionais e administradores podem criar atividades'
      });
    }
    
    const {
      paciente_id,
      titulo,
      descricao,
      objetivos,
      recursos_necessarios,
      instrucoes,
      data_inicio,
      data_fim,
      prioridade
    } = req.body;
    
    // Validar campos obrigatórios
    if (!paciente_id || !titulo) {
      return res.status(400).json({
        status: 'error',
        message: 'Paciente e título são obrigatórios'
      });
    }
    
    // Obter ID do perfil do profissional
    let profissionalId;
    
    if (userType === 'PROFISSIONAL') {
      const profissionalPerfil = await get(
        'SELECT id FROM perfis_profissionais WHERE usuario_id = ?',
        [userId]
      );
      
      if (!profissionalPerfil) {
        return res.status(404).json({
          status: 'error',
          message: 'Perfil de profissional não encontrado'
        });
      }
      
      profissionalId = profissionalPerfil.id;
    } else {
      // Se for admin, o ID do profissional deve ser fornecido
      profissionalId = req.body.profissional_id;
      
      if (!profissionalId) {
        return res.status(400).json({
          status: 'error',
          message: 'ID do profissional é obrigatório para administradores'
        });
      }
    }
    
    // Verificar se o paciente existe
    const pacienteExists = await get(
      'SELECT id FROM perfis_pacientes WHERE id = ?',
      [paciente_id]
    );
    
    if (!pacienteExists) {
      return res.status(404).json({
        status: 'error',
        message: 'Paciente não encontrado'
      });
    }
    
    // Verificar se existe vínculo entre profissional e paciente
    const vinculoExists = await get(
      'SELECT id FROM vinculos_profissional_paciente WHERE profissional_id = ? AND paciente_id = ? AND status = "ativo"',
      [profissionalId, paciente_id]
    );
    
    if (!vinculoExists && userType !== 'ADMIN') {
      return res.status(403).json({
        status: 'error',
        message: 'Não existe vínculo ativo entre este profissional e paciente'
      });
    }
    
    // Inserir atividade
    const result = await run(
      `INSERT INTO atividades (
        profissional_id, paciente_id, titulo, descricao, 
        objetivos, recursos_necessarios, instrucoes, 
        data_inicio, data_fim, prioridade
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        profissionalId, paciente_id, titulo, descricao || null,
        objetivos || null, recursos_necessarios || null, instrucoes || null,
        data_inicio || null, data_fim || null, prioridade || 'media'
      ]
    );
    
    // Resposta de sucesso
    return res.status(201).json({
      status: 'success',
      message: 'Atividade criada com sucesso',
      data: {
        id: result.lastID,
        profissional_id: profissionalId,
        paciente_id,
        titulo
      }
    });
  } catch (error) {
    logger.error(`Erro ao criar atividade: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao criar atividade',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Atualizar atividade
const updateActivity = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { id } = req.params;
    
    // Verificar se a atividade existe
    const atividade = await get('SELECT * FROM atividades WHERE id = ?', [id]);
    
    if (!atividade) {
      return res.status(404).json({
        status: 'error',
        message: 'Atividade não encontrada'
      });
    }
    
    // Verificar permissão de edição
    let temPermissao = false;
    
    if (userType === 'ADMIN') {
      // Administradores podem editar todas as atividades
      temPermissao = true;
    } else if (userType === 'PROFISSIONAL') {
      // Profissionais editam apenas suas atividades
      const profissionalPerfil = await get(
        'SELECT id FROM perfis_profissionais WHERE usuario_id = ?',
        [userId]
      );
      
      temPermissao = profissionalPerfil && profissionalPerfil.id === atividade.profissional_id;
    }
    
    if (!temPermissao) {
      return res.status(403).json({
        status: 'error',
        message: 'Acesso não autorizado para editar esta atividade'
      });
    }
    
    const {
      titulo,
      descricao,
      objetivos,
      recursos_necessarios,
      instrucoes,
      data_inicio,
      data_fim,
      status,
      prioridade,
      feedback_profissional
    } = req.body;
    
    // Construir query de atualização
    let updateFields = [];
    let updateParams = [];
    
    if (titulo !== undefined) {
      updateFields.push('titulo = ?');
      updateParams.push(titulo);
    }
    
    if (descricao !== undefined) {
      updateFields.push('descricao = ?');
      updateParams.push(descricao);
    }
    
    if (objetivos !== undefined) {
      updateFields.push('objetivos = ?');
      updateParams.push(objetivos);
    }
    
    if (recursos_necessarios !== undefined) {
      updateFields.push('recursos_necessarios = ?');
      updateParams.push(recursos_necessarios);
    }
    
    if (instrucoes !== undefined) {
      updateFields.push('instrucoes = ?');
      updateParams.push(instrucoes);
    }
    
    if (data_inicio !== undefined) {
      updateFields.push('data_inicio = ?');
      updateParams.push(data_inicio);
    }
    
    if (data_fim !== undefined) {
      updateFields.push('data_fim = ?');
      updateParams.push(data_fim);
    }
    
    if (status !== undefined) {
      updateFields.push('status = ?');
      updateParams.push(status);
    }
    
    if (prioridade !== undefined) {
      updateFields.push('prioridade = ?');
      updateParams.push(prioridade);
    }
    
    if (feedback_profissional !== undefined) {
      updateFields.push('feedback_profissional = ?');
      updateParams.push(feedback_profissional);
    }
    
    // Se não houver campos para atualizar
    if (updateFields.length === 0) {
      return res.status(400).json({
        status: 'error',
        message: 'Nenhum campo fornecido para atualização'
      });
    }
    
    // Adicionar ID da atividade aos parâmetros
    updateParams.push(id);
    
    // Executar atualização
    await run(
      `UPDATE atividades SET ${updateFields.join(', ')} WHERE id = ?`,
      updateParams
    );
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Atividade atualizada com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao atualizar atividade: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao atualizar atividade',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Atualizar feedback do paciente
const updatePatientFeedback = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { id } = req.params;
    const { feedback_paciente } = req.body;
    
    // Apenas pacientes podem atualizar seu feedback
    if (userType !== 'PACIENTE' && userType !== 'ADMIN') {
      return res.status(403).json({
        status: 'error',
        message: 'Apenas pacientes e administradores podem atualizar o feedback do paciente'
      });
    }
    
    // Verificar se a atividade existe
    const atividade = await get('SELECT * FROM atividades WHERE id = ?', [id]);
    
    if (!atividade) {
      return res.status(404).json({
        status: 'error',
        message: 'Atividade não encontrada'
      });
    }
    
    // Verificar permissão
    if (userType === 'PACIENTE') {
      const pacientePerfil = await get(
        'SELECT id FROM perfis_pacientes WHERE usuario_id = ?',
        [userId]
      );
      
      if (!pacientePerfil || pacientePerfil.id !== atividade.paciente_id) {
        return res.status(403).json({
          status: 'error',
          message: 'Acesso não autorizado para atualizar o feedback desta atividade'
        });
      }
    }
    
    // Atualizar feedback
    await run(
      'UPDATE atividades SET feedback_paciente = ? WHERE id = ?',
      [feedback_paciente, id]
    );
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Feedback atualizado com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao atualizar feedback do paciente: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao atualizar feedback do paciente',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Excluir atividade
const deleteActivity = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { id } = req.params;
    
    // Verificar se a atividade existe
    const atividade = await get('SELECT * FROM atividades WHERE id = ?', [id]);
    
    if (!atividade) {
      return res.status(404).json({
        status: 'error',
        message: 'Atividade não encontrada'
      });
    }
    
    // Verificar permissão de exclusão
    let temPermissao = false;
    
    if (userType === 'ADMIN') {
      // Administradores podem excluir todas as atividades
      temPermissao = true;
    } else if (userType === 'PROFISSIONAL') {
      // Profissionais excluem apenas suas atividades
      const profissionalPerfil = await get(
        'SELECT id FROM perfis_profissionais WHERE usuario_id = ?',
        [userId]
      );
      
      temPermissao = profissionalPerfil && profissionalPerfil.id === atividade.profissional_id;
    }
    
    if (!temPermissao) {
      return res.status(403).json({
        status: 'error',
        message: 'Acesso não autorizado para excluir esta atividade'
      });
    }
    
    // Excluir atividade
    await run('DELETE FROM atividades WHERE id = ?', [id]);
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Atividade excluída com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao excluir atividade: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao excluir atividade',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

module.exports = {
  listActivities,
  getActivity,
  createActivity,
  updateActivity,
  updatePatientFeedback,
  deleteActivity
};
