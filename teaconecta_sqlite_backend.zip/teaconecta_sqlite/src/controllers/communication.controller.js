// Controlador de comunicações
const { run, get, all } = require('../config/db');
const { logger } = require('../utils/logger');

// Listar comunicações
const listCommunications = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { tipo, status, data_inicio, data_fim } = req.query;
    
    let query = '';
    let params = [];
    
    // Construir query com base no tipo de usuário
    if (userType === 'ADMIN') {
      // Administradores podem ver todas as comunicações
      query = `
        SELECT c.*,
               u_rem.nome as remetente_nome,
               u_dest.nome as destinatario_nome
        FROM comunicacoes c
        JOIN usuarios u_rem ON c.remetente_id = u_rem.id
        JOIN usuarios u_dest ON c.destinatario_id = u_dest.id
        WHERE 1=1
      `;
    } else {
      // Outros usuários veem apenas suas comunicações (enviadas ou recebidas)
      query = `
        SELECT c.*,
               u_rem.nome as remetente_nome,
               u_dest.nome as destinatario_nome
        FROM comunicacoes c
        JOIN usuarios u_rem ON c.remetente_id = u_rem.id
        JOIN usuarios u_dest ON c.destinatario_id = u_dest.id
        WHERE c.remetente_id = ? OR c.destinatario_id = ?
      `;
      params.push(userId, userId);
    }
    
    // Adicionar filtros opcionais
    if (tipo === 'enviadas') {
      query += ' AND c.remetente_id = ?';
      params.push(userId);
    } else if (tipo === 'recebidas') {
      query += ' AND c.destinatario_id = ?';
      params.push(userId);
    }
    
    if (status) {
      query += ' AND c.status = ?';
      params.push(status);
    }
    
    if (data_inicio) {
      query += ' AND c.data_envio >= ?';
      params.push(data_inicio);
    }
    
    if (data_fim) {
      query += ' AND c.data_envio <= ?';
      params.push(data_fim);
    }
    
    // Ordenar por data de envio (mais recentes primeiro)
    query += ' ORDER BY c.data_envio DESC';
    
    // Executar a consulta
    const comunicacoes = await all(query, params);
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      data: comunicacoes
    });
  } catch (error) {
    logger.error(`Erro ao listar comunicações: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao listar comunicações',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Obter detalhes de uma comunicação
const getCommunication = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { id } = req.params;
    
    // Verificar se a comunicação existe
    const comunicacao = await get(
      `SELECT c.*,
              u_rem.nome as remetente_nome,
              u_dest.nome as destinatario_nome
       FROM comunicacoes c
       JOIN usuarios u_rem ON c.remetente_id = u_rem.id
       JOIN usuarios u_dest ON c.destinatario_id = u_dest.id
       WHERE c.id = ?`,
      [id]
    );
    
    if (!comunicacao) {
      return res.status(404).json({
        status: 'error',
        message: 'Comunicação não encontrada'
      });
    }
    
    // Verificar permissão de acesso
    let temPermissao = false;
    
    if (userType === 'ADMIN') {
      // Administradores podem ver todas as comunicações
      temPermissao = true;
    } else {
      // Outros usuários veem apenas suas comunicações (enviadas ou recebidas)
      temPermissao = comunicacao.remetente_id === userId || comunicacao.destinatario_id === userId;
    }
    
    if (!temPermissao) {
      return res.status(403).json({
        status: 'error',
        message: 'Acesso não autorizado a esta comunicação'
      });
    }
    
    // Se o usuário é o destinatário e está visualizando pela primeira vez, marcar como lida
    if (comunicacao.destinatario_id === userId && comunicacao.status === 'enviada') {
      await run(
        'UPDATE comunicacoes SET status = ?, data_leitura = CURRENT_TIMESTAMP WHERE id = ?',
        ['lida', id]
      );
      
      comunicacao.status = 'lida';
      comunicacao.data_leitura = new Date().toISOString();
    }
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      data: comunicacao
    });
  } catch (error) {
    logger.error(`Erro ao obter detalhes da comunicação: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao obter detalhes da comunicação',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Enviar nova comunicação
const sendCommunication = async (req, res) => {
  try {
    const userId = req.userId;
    
    const {
      destinatario_id,
      assunto,
      conteudo,
      anexos
    } = req.body;
    
    // Validar campos obrigatórios
    if (!destinatario_id || !assunto || !conteudo) {
      return res.status(400).json({
        status: 'error',
        message: 'Destinatário, assunto e conteúdo são obrigatórios'
      });
    }
    
    // Verificar se o destinatário existe
    const destinatarioExists = await get(
      'SELECT id FROM usuarios WHERE id = ?',
      [destinatario_id]
    );
    
    if (!destinatarioExists) {
      return res.status(404).json({
        status: 'error',
        message: 'Destinatário não encontrado'
      });
    }
    
    // Inserir comunicação
    const result = await run(
      `INSERT INTO comunicacoes (
        remetente_id, destinatario_id, assunto, conteudo, anexos
      ) VALUES (?, ?, ?, ?, ?)`,
      [
        userId, destinatario_id, assunto, conteudo, anexos ? JSON.stringify(anexos) : null
      ]
    );
    
    // Resposta de sucesso
    return res.status(201).json({
      status: 'success',
      message: 'Comunicação enviada com sucesso',
      data: {
        id: result.lastID,
        remetente_id: userId,
        destinatario_id,
        assunto,
        data_envio: new Date().toISOString()
      }
    });
  } catch (error) {
    logger.error(`Erro ao enviar comunicação: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao enviar comunicação',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Atualizar status da comunicação
const updateCommunicationStatus = async (req, res) => {
  try {
    const userId = req.userId;
    const { id } = req.params;
    const { status } = req.body;
    
    // Validar status
    const statusValidos = ['lida', 'respondida', 'arquivada'];
    if (!statusValidos.includes(status)) {
      return res.status(400).json({
        status: 'error',
        message: 'Status inválido'
      });
    }
    
    // Verificar se a comunicação existe
    const comunicacao = await get(
      'SELECT * FROM comunicacoes WHERE id = ?',
      [id]
    );
    
    if (!comunicacao) {
      return res.status(404).json({
        status: 'error',
        message: 'Comunicação não encontrada'
      });
    }
    
    // Verificar permissão (apenas o destinatário pode atualizar o status)
    if (comunicacao.destinatario_id !== userId) {
      return res.status(403).json({
        status: 'error',
        message: 'Apenas o destinatário pode atualizar o status da comunicação'
      });
    }
    
    // Atualizar status
    await run(
      'UPDATE comunicacoes SET status = ? WHERE id = ?',
      [status, id]
    );
    
    // Se estiver marcando como lida pela primeira vez, atualizar data de leitura
    if (status === 'lida' && !comunicacao.data_leitura) {
      await run(
        'UPDATE comunicacoes SET data_leitura = CURRENT_TIMESTAMP WHERE id = ?',
        [id]
      );
    }
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Status da comunicação atualizado com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao atualizar status da comunicação: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao atualizar status da comunicação',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Excluir comunicação
const deleteCommunication = async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { id } = req.params;
    
    // Verificar se a comunicação existe
    const comunicacao = await get(
      'SELECT * FROM comunicacoes WHERE id = ?',
      [id]
    );
    
    if (!comunicacao) {
      return res.status(404).json({
        status: 'error',
        message: 'Comunicação não encontrada'
      });
    }
    
    // Verificar permissão de exclusão
    let temPermissao = false;
    
    if (userType === 'ADMIN') {
      // Administradores podem excluir todas as comunicações
      temPermissao = true;
    } else {
      // Outros usuários excluem apenas suas comunicações (enviadas ou recebidas)
      temPermissao = comunicacao.remetente_id === userId || comunicacao.destinatario_id === userId;
    }
    
    if (!temPermissao) {
      return res.status(403).json({
        status: 'error',
        message: 'Acesso não autorizado para excluir esta comunicação'
      });
    }
    
    // Excluir comunicação
    await run('DELETE FROM comunicacoes WHERE id = ?', [id]);
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Comunicação excluída com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao excluir comunicação: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao excluir comunicação',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

module.exports = {
  listCommunications,
  getCommunication,
  sendCommunication,
  updateCommunicationStatus,
  deleteCommunication
};
