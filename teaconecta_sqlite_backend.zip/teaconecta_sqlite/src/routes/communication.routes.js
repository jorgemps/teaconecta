// Rotas de comunicação
const express = require('express');
const router = express.Router();
const communicationController = require('../controllers/communication.controller');
const { authMiddleware } = require('../middlewares/auth.middleware');

// Todas as rotas de comunicação são protegidas
router.use(authMiddleware);

// Listar comunicações
router.get('/', communicationController.listCommunications);

// Obter detalhes de uma comunicação
router.get('/:id', communicationController.getCommunication);

// Enviar nova comunicação
router.post('/', communicationController.sendCommunication);

// Atualizar status da comunicação
router.patch('/:id/status', communicationController.updateCommunicationStatus);

// Excluir comunicação
router.delete('/:id', communicationController.deleteCommunication);

module.exports = router;
