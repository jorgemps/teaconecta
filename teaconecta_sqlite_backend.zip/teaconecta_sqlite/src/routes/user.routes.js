// Rotas de usuários
const express = require('express');
const router = express.Router();
const { authMiddleware, checkRole } = require('../middlewares/auth.middleware');
const { run, get, all } = require('../config/db');
const { logger } = require('../utils/logger');

// Todas as rotas de usuários são protegidas
router.use(authMiddleware);

// Listar usuários
router.get('/', async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { tipo_perfil, status } = req.query;
    
    let query = '';
    let params = [];
    
    // Construir query com base no tipo de usuário
    if (userType === 'ADMIN') {
      // Administradores podem ver todos os usuários
      query = 'SELECT id, nome, email, telefone, tipo_perfil, status, data_cadastro, ultimo_acesso FROM usuarios WHERE 1=1';
    } else if (userType === 'CLINICA') {
      // Clínicas veem apenas seus profissionais vinculados e pacientes desses profissionais
      query = `
        SELECT DISTINCT u.id, u.nome, u.email, u.telefone, u.tipo_perfil, u.status, u.data_cadastro, u.ultimo_acesso
        FROM usuarios u
        LEFT JOIN perfis_profissionais pp ON u.id = pp.usuario_id
        LEFT JOIN vinculos_clinica_profissional vcp ON pp.id = vcp.profissional_id
        LEFT JOIN perfis_clinicas pc ON vcp.clinica_id = pc.id
        LEFT JOIN perfis_pacientes pac ON u.id = pac.usuario_id
        LEFT JOIN vinculos_profissional_paciente vpp ON pac.id = vpp.paciente_id
        WHERE (pc.usuario_id = ? AND u.tipo_perfil = 'PROFISSIONAL')
           OR (vpp.profissional_id IN (
                SELECT pp2.id 
                FROM perfis_profissionais pp2
                JOIN vinculos_clinica_profissional vcp2 ON pp2.id = vcp2.profissional_id
                JOIN perfis_clinicas pc2 ON vcp2.clinica_id = pc2.id
                WHERE pc2.usuario_id = ?
              ) AND u.tipo_perfil = 'PACIENTE')
      `;
      params.push(userId, userId);
    } else if (userType === 'PROFISSIONAL') {
      // Profissionais veem apenas seus pacientes vinculados
      query = `
        SELECT u.id, u.nome, u.email, u.telefone, u.tipo_perfil, u.status, u.data_cadastro, u.ultimo_acesso
        FROM usuarios u
        JOIN perfis_pacientes pp ON u.id = pp.usuario_id
        JOIN vinculos_profissional_paciente vpp ON pp.id = vpp.paciente_id
        JOIN perfis_profissionais prof ON vpp.profissional_id = prof.id
        WHERE prof.usuario_id = ?
      `;
      params.push(userId);
    } else {
      // Pacientes veem apenas a si mesmos
      query = 'SELECT id, nome, email, telefone, tipo_perfil, status, data_cadastro, ultimo_acesso FROM usuarios WHERE id = ?';
      params.push(userId);
    }
    
    // Adicionar filtros opcionais
    if (tipo_perfil) {
      query += ' AND tipo_perfil = ?';
      params.push(tipo_perfil);
    }
    
    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }
    
    // Executar a consulta
    const usuarios = await all(query, params);
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      data: usuarios
    });
  } catch (error) {
    logger.error(`Erro ao listar usuários: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao listar usuários',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Obter detalhes de um usuário
router.get('/:id', async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { id } = req.params;
    
    // Verificar se o usuário existe
    const user = await get('SELECT id, nome, email, telefone, tipo_perfil, status, data_cadastro, ultimo_acesso FROM usuarios WHERE id = ?', [id]);
    
    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'Usuário não encontrado'
      });
    }
    
    // Verificar permissão de acesso
    let temPermissao = false;
    
    if (userType === 'ADMIN') {
      // Administradores podem ver todos os usuários
      temPermissao = true;
    } else if (userType === 'CLINICA' && user.tipo_perfil === 'PROFISSIONAL') {
      // Clínicas podem ver detalhes de seus profissionais vinculados
      const vinculoExists = await get(
        `SELECT vcp.id 
         FROM vinculos_clinica_profissional vcp
         JOIN perfis_clinicas pc ON vcp.clinica_id = pc.id
         JOIN perfis_profissionais pp ON vcp.profissional_id = pp.id
         WHERE pc.usuario_id = ? AND pp.usuario_id = ?`,
        [userId, id]
      );
      
      temPermissao = !!vinculoExists;
    } else if (userType === 'CLINICA' && user.tipo_perfil === 'PACIENTE') {
      // Clínicas podem ver detalhes de pacientes de seus profissionais
      const vinculoExists = await get(
        `SELECT vpp.id 
         FROM vinculos_profissional_paciente vpp
         JOIN perfis_pacientes pp ON vpp.paciente_id = pp.id
         JOIN perfis_profissionais prof ON vpp.profissional_id = prof.id
         JOIN vinculos_clinica_profissional vcp ON prof.id = vcp.profissional_id
         JOIN perfis_clinicas pc ON vcp.clinica_id = pc.id
         WHERE pc.usuario_id = ? AND pp.usuario_id = ?`,
        [userId, id]
      );
      
      temPermissao = !!vinculoExists;
    } else if (userType === 'PROFISSIONAL' && user.tipo_perfil === 'PACIENTE') {
      // Profissionais podem ver detalhes de seus pacientes vinculados
      const vinculoExists = await get(
        `SELECT vpp.id 
         FROM vinculos_profissional_paciente vpp
         JOIN perfis_pacientes pp ON vpp.paciente_id = pp.id
         JOIN perfis_profissionais prof ON vpp.profissional_id = prof.id
         WHERE prof.usuario_id = ? AND pp.usuario_id = ?`,
        [userId, id]
      );
      
      temPermissao = !!vinculoExists;
    } else {
      // Outros usuários veem apenas a si mesmos
      temPermissao = userId === parseInt(id);
    }
    
    if (!temPermissao) {
      return res.status(403).json({
        status: 'error',
        message: 'Acesso não autorizado a este usuário'
      });
    }
    
    // Buscar dados específicos do perfil com base no tipo
    let profileData = {};
    
    if (user.tipo_perfil === 'CLINICA') {
      profileData = await get('SELECT * FROM perfis_clinicas WHERE usuario_id = ?', [id]) || {};
    } else if (user.tipo_perfil === 'PROFISSIONAL') {
      profileData = await get('SELECT * FROM perfis_profissionais WHERE usuario_id = ?', [id]) || {};
    } else if (user.tipo_perfil === 'PACIENTE') {
      profileData = await get('SELECT * FROM perfis_pacientes WHERE usuario_id = ?', [id]) || {};
    }
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      data: {
        user,
        profile_data: profileData
      }
    });
  } catch (error) {
    logger.error(`Erro ao obter detalhes do usuário: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao obter detalhes do usuário',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Atualizar usuário
router.put('/:id', async (req, res) => {
  try {
    const userId = req.userId;
    const userType = req.userType;
    const { id } = req.params;
    
    // Verificar se o usuário existe
    const user = await get('SELECT * FROM usuarios WHERE id = ?', [id]);
    
    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'Usuário não encontrado'
      });
    }
    
    // Verificar permissão de edição
    let temPermissao = false;
    
    if (userType === 'ADMIN') {
      // Administradores podem editar todos os usuários
      temPermissao = true;
    } else {
      // Outros usuários editam apenas a si mesmos
      temPermissao = userId === parseInt(id);
    }
    
    if (!temPermissao) {
      return res.status(403).json({
        status: 'error',
        message: 'Acesso não autorizado para editar este usuário'
      });
    }
    
    const { nome, telefone, dados_perfil } = req.body;
    
    // Atualizar dados básicos do usuário
    if (nome || telefone) {
      let updateFields = [];
      let updateParams = [];
      
      if (nome) {
        updateFields.push('nome = ?');
        updateParams.push(nome);
      }
      
      if (telefone) {
        updateFields.push('telefone = ?');
        updateParams.push(telefone);
      }
      
      // Adicionar ID do usuário aos parâmetros
      updateParams.push(id);
      
      // Executar atualização
      await run(
        `UPDATE usuarios SET ${updateFields.join(', ')} WHERE id = ?`,
        updateParams
      );
    }
    
    // Atualizar dados específicos do perfil
    if (dados_perfil) {
      if (user.tipo_perfil === 'CLINICA') {
        // Extrair dados do perfil da clínica
        const {
          cnpj,
          razao_social,
          nome_fantasia,
          endereco_cep,
          endereco_logradouro,
          endereco_numero,
          endereco_complemento,
          endereco_bairro,
          endereco_cidade,
          endereco_estado,
          telefone_comercial,
          email_comercial,
          site
        } = dados_perfil;
        
        // Construir query de atualização
        let updateFields = [];
        let updateParams = [];
        
        if (cnpj !== undefined) {
          updateFields.push('cnpj = ?');
          updateParams.push(cnpj);
        }
        
        if (razao_social !== undefined) {
          updateFields.push('razao_social = ?');
          updateParams.push(razao_social);
        }
        
        if (nome_fantasia !== undefined) {
          updateFields.push('nome_fantasia = ?');
          updateParams.push(nome_fantasia);
        }
        
        if (endereco_cep !== undefined) {
          updateFields.push('endereco_cep = ?');
          updateParams.push(endereco_cep);
        }
        
        if (endereco_logradouro !== undefined) {
          updateFields.push('endereco_logradouro = ?');
          updateParams.push(endereco_logradouro);
        }
        
        if (endereco_numero !== undefined) {
          updateFields.push('endereco_numero = ?');
          updateParams.push(endereco_numero);
        }
        
        if (endereco_complemento !== undefined) {
          updateFields.push('endereco_complemento = ?');
          updateParams.push(endereco_complemento);
        }
        
        if (endereco_bairro !== undefined) {
          updateFields.push('endereco_bairro = ?');
          updateParams.push(endereco_bairro);
        }
        
        if (endereco_cidade !== undefined) {
          updateFields.push('endereco_cidade = ?');
          updateParams.push(endereco_cidade);
        }
        
        if (endereco_estado !== undefined) {
          updateFields.push('endereco_estado = ?');
          updateParams.push(endereco_estado);
        }
        
        if (telefone_comercial !== undefined) {
          updateFields.push('telefone_comercial = ?');
          updateParams.push(telefone_comercial);
        }
        
        if (email_comercial !== undefined) {
          updateFields.push('email_comercial = ?');
          updateParams.push(email_comercial);
        }
        
        if (site !== undefined) {
          updateFields.push('site = ?');
          updateParams.push(site);
        }
        
        if (updateFields.length > 0) {
          // Obter ID do perfil
          const perfil = await get('SELECT id FROM perfis_clinicas WHERE usuario_id = ?', [id]);
          
          if (perfil) {
            // Adicionar ID do perfil aos parâmetros
            updateParams.push(perfil.id);
            
            // Executar atualização
            await run(
              `UPDATE perfis_clinicas SET ${updateFields.join(', ')} WHERE id = ?`,
              updateParams
            );
          }
        }
      } else if (user.tipo_perfil === 'PROFISSIONAL') {
        // Extrair dados do perfil do profissional
        const {
          registro_profissional,
          especialidade,
          formacao,
          biografia,
          foto_perfil,
          disponibilidade_inicio,
          disponibilidade_fim,
          dias_disponibilidade,
          valor_sessao,
          duracao_sessao
        } = dados_perfil;
        
        // Construir query de atualização
        let updateFields = [];
        let updateParams = [];
        
        if (registro_profissional !== undefined) {
          updateFields.push('registro_profissional = ?');
          updateParams.push(registro_profissional);
        }
        
        if (especialidade !== undefined) {
          updateFields.push('especialidade = ?');
          updateParams.push(especialidade);
        }
        
        if (formacao !== undefined) {
          updateFields.push('formacao = ?');
          updateParams.push(formacao);
        }
        
        if (biografia !== undefined) {
          updateFields.push('biografia = ?');
          updateParams.push(biografia);
        }
        
        if (foto_perfil !== undefined) {
          updateFields.push('foto_perfil = ?');
          updateParams.push(foto_perfil);
        }
        
        if (disponibilidade_inicio !== undefined) {
          updateFields.push('disponibilidade_inicio = ?');
          updateParams.push(disponibilidade_inicio);
        }
        
        if (disponibilidade_fim !== undefined) {
          updateFields.push('disponibilidade_fim = ?');
          updateParams.push(disponibilidade_fim);
        }
        
        if (dias_disponibilidade !== undefined) {
          updateFields.push('dias_disponibilidade = ?');
          updateParams.push(dias_disponibilidade);
        }
        
        if (valor_sessao !== undefined) {
          updateFields.push('valor_sessao = ?');
          updateParams.push(valor_sessao);
        }
        
        if (duracao_sessao !== undefined) {
          updateFields.push('duracao_sessao = ?');
          updateParams.push(duracao_sessao);
        }
        
        if (updateFields.length > 0) {
          // Obter ID do perfil
          const perfil = await get('SELECT id FROM perfis_profissionais WHERE usuario_id = ?', [id]);
          
          if (perfil) {
            // Adicionar ID do perfil aos parâmetros
            updateParams.push(perfil.id);
            
            // Executar atualização
            await run(
              `UPDATE perfis_profissionais SET ${updateFields.join(', ')} WHERE id = ?`,
              updateParams
            );
          }
        }
      } else if (user.tipo_perfil === 'PACIENTE') {
        // Extrair dados do perfil do paciente
        const {
          data_nascimento,
          genero,
          diagnostico,
          nivel_suporte,
          observacoes,
          alergias,
          medicamentos,
          responsavel_nome,
          responsavel_telefone,
          responsavel_email,
          responsavel_parentesco
        } = dados_perfil;
        
        // Construir query de atualização
        let updateFields = [];
        let updateParams = [];
        
        if (data_nascimento !== undefined) {
          updateFields.push('data_nascimento = ?');
          updateParams.push(data_nascimento);
        }
        
        if (genero !== undefined) {
          updateFields.push('genero = ?');
          updateParams.push(genero);
        }
        
        if (diagnostico !== undefined) {
          updateFields.push('diagnostico = ?');
          updateParams.push(diagnostico);
        }
        
        if (nivel_suporte !== undefined) {
          updateFields.push('nivel_suporte = ?');
          updateParams.push(nivel_suporte);
        }
        
        if (observacoes !== undefined) {
          updateFields.push('observacoes = ?');
          updateParams.push(observacoes);
        }
        
        if (alergias !== undefined) {
          updateFields.push('alergias = ?');
          updateParams.push(alergias);
        }
        
        if (medicamentos !== undefined) {
          updateFields.push('medicamentos = ?');
          updateParams.push(medicamentos);
        }
        
        if (responsavel_nome !== undefined) {
          updateFields.push('responsavel_nome = ?');
          updateParams.push(responsavel_nome);
        }
        
        if (responsavel_telefone !== undefined) {
          updateFields.push('responsavel_telefone = ?');
          updateParams.push(responsavel_telefone);
        }
        
        if (responsavel_email !== undefined) {
          updateFields.push('responsavel_email = ?');
          updateParams.push(responsavel_email);
        }
        
        if (responsavel_parentesco !== undefined) {
          updateFields.push('responsavel_parentesco = ?');
          updateParams.push(responsavel_parentesco);
        }
        
        if (updateFields.length > 0) {
          // Obter ID do perfil
          const perfil = await get('SELECT id FROM perfis_pacientes WHERE usuario_id = ?', [id]);
          
          if (perfil) {
            // Adicionar ID do perfil aos parâmetros
            updateParams.push(perfil.id);
            
            // Executar atualização
            await run(
              `UPDATE perfis_pacientes SET ${updateFields.join(', ')} WHERE id = ?`,
              updateParams
            );
          }
        }
      }
    }
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Usuário atualizado com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao atualizar usuário: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao atualizar usuário',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Excluir usuário (apenas admin)
router.delete('/:id', checkRole(['ADMIN']), async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar se o usuário existe
    const user = await get('SELECT * FROM usuarios WHERE id = ?', [id]);
    
    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'Usuário não encontrado'
      });
    }
    
    // Excluir usuário
    await run('DELETE FROM usuarios WHERE id = ?', [id]);
    
    // Resposta de sucesso
    return res.status(200).json({
      status: 'success',
      message: 'Usuário excluído com sucesso'
    });
  } catch (error) {
    logger.error(`Erro ao excluir usuário: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro ao excluir usuário',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

module.exports = router;
