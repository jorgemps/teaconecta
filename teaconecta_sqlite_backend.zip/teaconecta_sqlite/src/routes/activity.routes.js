// Rotas de atividades
const express = require('express');
const router = express.Router();
const activityController = require('../controllers/activity.controller');
const { authMiddleware, checkRole } = require('../middlewares/auth.middleware');

// Todas as rotas de atividades são protegidas
router.use(authMiddleware);

// Listar atividades
router.get('/', activityController.listActivities);

// Obter detalhes de uma atividade
router.get('/:id', activityController.getActivity);

// Criar nova atividade (apenas profissionais e admins)
router.post('/', checkRole(['PROFISSIONAL', 'ADMIN']), activityController.createActivity);

// Atualizar atividade (apenas profissionais e admins)
router.put('/:id', checkRole(['PROFISSIONAL', 'ADMIN']), activityController.updateActivity);

// Atualizar feedback do paciente (apenas pacientes e admins)
router.patch('/:id/feedback', checkRole(['PACIENTE', 'ADMIN']), activityController.updatePatientFeedback);

// Excluir atividade (apenas profissionais e admins)
router.delete('/:id', checkRole(['PROFISSIONAL', 'ADMIN']), activityController.deleteActivity);

module.exports = router;
