// Middleware de tratamento de erros
const { logger } = require('../utils/logger');

const errorMiddleware = (err, req, res, next) => {
  // Registrar erro no log
  logger.error(`Erro: ${err.message}`);
  
  // Verificar se é um erro conhecido
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      status: 'error',
      message: 'Erro de validação',
      errors: err.errors
    });
  }
  
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      status: 'error',
      message: 'Não autorizado'
    });
  }
  
  // Erro interno do servidor
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Erro interno do servidor';
  
  return res.status(statusCode).json({
    status: 'error',
    message,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
};

module.exports = errorMiddleware;
