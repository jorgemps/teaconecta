// Middleware de autenticação
const jwt = require('jsonwebtoken');
const { logger } = require('../utils/logger');
require('dotenv').config();

// Middleware para verificar token JWT
const authMiddleware = (req, res, next) => {
  try {
    // Obter o token do header Authorization
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      return res.status(401).json({
        status: 'error',
        message: 'Token de autenticação não fornecido'
      });
    }
    
    // Verificar formato do token (Bearer token)
    const parts = authHeader.split(' ');
    
    if (parts.length !== 2) {
      return res.status(401).json({
        status: 'error',
        message: 'Erro no formato do token'
      });
    }
    
    const [scheme, token] = parts;
    
    if (!/^Bearer$/i.test(scheme)) {
      return res.status(401).json({
        status: 'error',
        message: 'Token mal formatado'
      });
    }
    
    // Verificar e decodificar o token
    jwt.verify(token, process.env.JWT_SECRET || 'teaconecta_secret_key', (err, decoded) => {
      if (err) {
        logger.error(`Erro na verificação do token: ${err.message}`);
        
        if (err.name === 'TokenExpiredError') {
          return res.status(401).json({
            status: 'error',
            message: 'Token expirado'
          });
        }
        
        return res.status(401).json({
          status: 'error',
          message: 'Token inválido'
        });
      }
      
      // Adicionar informações do usuário ao objeto de requisição
      req.userId = decoded.id;
      req.userType = decoded.tipo_perfil;
      
      return next();
    });
  } catch (error) {
    logger.error(`Erro no middleware de autenticação: ${error.message}`);
    return res.status(500).json({
      status: 'error',
      message: 'Erro interno no servidor'
    });
  }
};

// Middleware para verificar perfil do usuário
const checkRole = (roles) => {
  return (req, res, next) => {
    try {
      // Verificar se o tipo de perfil do usuário está na lista de perfis permitidos
      if (!roles.includes(req.userType)) {
        return res.status(403).json({
          status: 'error',
          message: 'Acesso não autorizado para este perfil de usuário'
        });
      }
      
      return next();
    } catch (error) {
      logger.error(`Erro no middleware de verificação de perfil: ${error.message}`);
      return res.status(500).json({
        status: 'error',
        message: 'Erro interno no servidor'
      });
    }
  };
};

module.exports = {
  authMiddleware,
  checkRole
};
