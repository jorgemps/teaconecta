// Script de inicialização do banco de dados SQLite
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { db, run, get } = require('../config/db');
const { logger } = require('../utils/logger');
require('dotenv').config();

// Função principal para inicializar o banco de dados
const initDb = async () => {
  try {
    logger.info('Iniciando criação do banco de dados SQLite...');

    // Verificar se o diretório database existe
    const dbDir = path.join(__dirname, '../../database');
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
      logger.info('Diretório database criado com sucesso');
    }

    // Ler o arquivo de schema SQL
    const schemaPath = path.join(__dirname, '../../database/schema.sql');
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');

    // Executar o script de criação de tabelas
    logger.info('Executando script de criação de tabelas...');
    
    // Dividir o script em comandos individuais e executá-los
    const commands = schemaSql
      .split(';')
      .filter(cmd => cmd.trim() !== '')
      .map(cmd => cmd.trim() + ';');
    
    for (const command of commands) {
      await run(command);
    }
    
    // Verificar se o usuário admin já existe
    const adminExists = await get('SELECT * FROM usuarios WHERE email = ?', ['admin@teaconecta.com']);

    if (!adminExists) {
      logger.info('Criando usuário administrador padrão...');
      
      // Hash da senha padrão (admin123)
      const salt = await bcrypt.genSalt(10);
      const senhaHash = await bcrypt.hash('admin123', salt);

      // Inserir usuário admin
      await run(
        'INSERT INTO usuarios (nome, email, senha_hash, telefone, tipo_perfil) VALUES (?, ?, ?, ?, ?)',
        ['Administrador', 'admin@teaconecta.com', senhaHash, '(00) 00000-0000', 'ADMIN']
      );
      
      logger.info('Usuário admin criado com email: admin@teaconecta.com e senha: admin123');
    } else {
      logger.info('Usuário administrador já existe, pulando criação');
    }
    
    logger.info('Banco de dados SQLite inicializado com sucesso!');
    
  } catch (error) {
    logger.error(`Erro ao inicializar banco de dados SQLite: ${error.message}`);
    throw error;
  }
};

// Executar a função se o script for chamado diretamente
if (require.main === module) {
  initDb()
    .then(() => {
      logger.info('Script de inicialização concluído com sucesso');
      process.exit(0);
    })
    .catch((error) => {
      logger.error(`Erro durante a inicialização: ${error.message}`);
      process.exit(1);
    });
}

module.exports = { initDb };
