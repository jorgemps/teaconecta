// Arquivo do servidor
const app = require('./app');
const { logger } = require('./utils/logger');
const { initDb } = require('./scripts/initDb');
require('dotenv').config();

// Definir porta
const PORT = process.env.PORT || 3000;

// Inicializar banco de dados antes de iniciar o servidor
const startServer = async () => {
  try {
    // Inicializar banco de dados
    await initDb();
    
    // Iniciar servidor
    app.listen(PORT, '0.0.0.0', () => {
      logger.info(`Servidor TEAconecta rodando na porta ${PORT}`);
      logger.info(`Acesse: http://localhost:${PORT}/api/status`);
    });
  } catch (error) {
    logger.error(`Erro ao iniciar servidor: ${error.message}`);
    process.exit(1);
  }
};

// Iniciar servidor
startServer();
