// Arquivo principal do servidor
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const { logger } = require('./utils/logger');
require('dotenv').config();

// Importar rotas
const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const activityRoutes = require('./routes/activity.routes');
const communicationRoutes = require('./routes/communication.routes');

// Importar middlewares
const errorMiddleware = require('./middlewares/error.middleware');

// Inicializar app Express
const app = express();

// Configurar middlewares
app.use(helmet()); // Segurança
app.use(cors()); // CORS
app.use(express.json()); // Parse de JSON
app.use(express.urlencoded({ extended: true })); // Parse de URL-encoded
app.use(morgan('dev')); // Logging de requisições

// Definir rotas
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/activities', activityRoutes);
app.use('/api/communications', communicationRoutes);

// Rota de status
app.get('/api/status', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'API do TEAconecta está funcionando!',
    version: '1.0.0',
    timestamp: new Date()
  });
});

// Middleware de tratamento de erros
app.use(errorMiddleware);

// Exportar app
module.exports = app;
