// Configuração de conexão com o banco de dados SQLite
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const { logger } = require('../utils/logger');

// Caminho para o arquivo do banco de dados
const dbPath = path.join(__dirname, '../../database/teaconecta.db');

// Criar conexão com o banco de dados
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    logger.error(`Erro ao conectar ao banco de dados SQLite: ${err.message}`);
    return;
  }
  logger.info('Conectado ao banco de dados SQLite');
});

// Configurar o banco para usar foreign keys
db.run('PRAGMA foreign_keys = ON');

// Função para executar queries com promessas
const run = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) {
        logger.error(`Erro na execução da query: ${sql}`);
        logger.error(err.message);
        reject(err);
        return;
      }
      resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
};

// Função para consultas que retornam uma única linha
const get = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) {
        logger.error(`Erro na execução da query: ${sql}`);
        logger.error(err.message);
        reject(err);
        return;
      }
      resolve(row);
    });
  });
};

// Função para consultas que retornam múltiplas linhas
const all = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) {
        logger.error(`Erro na execução da query: ${sql}`);
        logger.error(err.message);
        reject(err);
        return;
      }
      resolve(rows);
    });
  });
};

// Função para executar múltiplas queries em uma transação
const transaction = async (callback) => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run('BEGIN TRANSACTION');
      
      try {
        const result = callback(db);
        db.run('COMMIT', (err) => {
          if (err) {
            logger.error(`Erro ao finalizar transação: ${err.message}`);
            reject(err);
            return;
          }
          resolve(result);
        });
      } catch (err) {
        db.run('ROLLBACK', (rollbackErr) => {
          if (rollbackErr) {
            logger.error(`Erro ao reverter transação: ${rollbackErr.message}`);
          }
          reject(err);
        });
      }
    });
  });
};

// Função para fechar a conexão com o banco
const close = () => {
  return new Promise((resolve, reject) => {
    db.close((err) => {
      if (err) {
        logger.error(`Erro ao fechar conexão com o banco: ${err.message}`);
        reject(err);
        return;
      }
      logger.info('Conexão com o banco de dados fechada');
      resolve();
    });
  });
};

module.exports = {
  db,
  run,
  get,
  all,
  transaction,
  close
};
