-- Schema SQL para SQLite
-- Criação das tabelas do TEAconecta

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  senha_hash TEXT NOT NULL,
  telefone TEXT,
  tipo_perfil TEXT NOT NULL CHECK (tipo_perfil IN ('ADMIN', 'CLINICA', 'PROFISSIONAL', 'PACIENTE')),
  status TEXT DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo', 'bloqueado')),
  data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ultimo_acesso TIMESTAMP
);

-- Tabela de perfis de clínicas
CREATE TABLE IF NOT EXISTS perfis_clinicas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  cnpj TEXT,
  razao_social TEXT,
  nome_fantasia TEXT,
  endereco_cep TEXT,
  endereco_logradouro TEXT,
  endereco_numero TEXT,
  endereco_complemento TEXT,
  endereco_bairro TEXT,
  endereco_cidade TEXT,
  endereco_estado TEXT,
  telefone_comercial TEXT,
  email_comercial TEXT,
  site TEXT,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de perfis de profissionais
CREATE TABLE IF NOT EXISTS perfis_profissionais (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  registro_profissional TEXT,
  especialidade TEXT,
  formacao TEXT,
  biografia TEXT,
  foto_perfil TEXT,
  disponibilidade_inicio TEXT,
  disponibilidade_fim TEXT,
  dias_disponibilidade TEXT,
  valor_sessao REAL,
  duracao_sessao INTEGER,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de perfis de pacientes
CREATE TABLE IF NOT EXISTS perfis_pacientes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  data_nascimento TEXT,
  genero TEXT,
  diagnostico TEXT,
  nivel_suporte TEXT CHECK (nivel_suporte IN ('1', '2', '3')),
  observacoes TEXT,
  alergias TEXT,
  medicamentos TEXT,
  responsavel_nome TEXT,
  responsavel_telefone TEXT,
  responsavel_email TEXT,
  responsavel_parentesco TEXT,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de vínculos entre clínicas e profissionais
CREATE TABLE IF NOT EXISTS vinculos_clinica_profissional (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  clinica_id INTEGER NOT NULL,
  profissional_id INTEGER NOT NULL,
  data_inicio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_fim TIMESTAMP,
  status TEXT DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo')),
  FOREIGN KEY (clinica_id) REFERENCES perfis_clinicas(id) ON DELETE CASCADE,
  FOREIGN KEY (profissional_id) REFERENCES perfis_profissionais(id) ON DELETE CASCADE
);

-- Tabela de vínculos entre profissionais e pacientes
CREATE TABLE IF NOT EXISTS vinculos_profissional_paciente (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  profissional_id INTEGER NOT NULL,
  paciente_id INTEGER NOT NULL,
  data_inicio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_fim TIMESTAMP,
  status TEXT DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo')),
  FOREIGN KEY (profissional_id) REFERENCES perfis_profissionais(id) ON DELETE CASCADE,
  FOREIGN KEY (paciente_id) REFERENCES perfis_pacientes(id) ON DELETE CASCADE
);

-- Tabela de sessões/atendimentos
CREATE TABLE IF NOT EXISTS sessoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  profissional_id INTEGER NOT NULL,
  paciente_id INTEGER NOT NULL,
  data_hora_inicio TIMESTAMP NOT NULL,
  data_hora_fim TIMESTAMP,
  status TEXT DEFAULT 'agendada' CHECK (status IN ('agendada', 'confirmada', 'realizada', 'cancelada')),
  tipo TEXT NOT NULL,
  modalidade TEXT CHECK (modalidade IN ('presencial', 'online')),
  local TEXT,
  link_online TEXT,
  observacoes TEXT,
  resumo TEXT,
  audio_gravacao TEXT,
  fotos TEXT,
  FOREIGN KEY (profissional_id) REFERENCES perfis_profissionais(id) ON DELETE CASCADE,
  FOREIGN KEY (paciente_id) REFERENCES perfis_pacientes(id) ON DELETE CASCADE
);

-- Tabela de atividades
CREATE TABLE IF NOT EXISTS atividades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  profissional_id INTEGER NOT NULL,
  paciente_id INTEGER NOT NULL,
  titulo TEXT NOT NULL,
  descricao TEXT,
  objetivos TEXT,
  recursos_necessarios TEXT,
  instrucoes TEXT,
  data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_inicio TIMESTAMP,
  data_fim TIMESTAMP,
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente', 'em_andamento', 'concluida', 'cancelada')),
  prioridade TEXT DEFAULT 'media' CHECK (prioridade IN ('baixa', 'media', 'alta')),
  feedback_paciente TEXT,
  feedback_profissional TEXT,
  FOREIGN KEY (profissional_id) REFERENCES perfis_profissionais(id) ON DELETE CASCADE,
  FOREIGN KEY (paciente_id) REFERENCES perfis_pacientes(id) ON DELETE CASCADE
);

-- Tabela de comunicações
CREATE TABLE IF NOT EXISTS comunicacoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  remetente_id INTEGER NOT NULL,
  destinatario_id INTEGER NOT NULL,
  assunto TEXT NOT NULL,
  conteudo TEXT NOT NULL,
  data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_leitura TIMESTAMP,
  status TEXT DEFAULT 'enviada' CHECK (status IN ('enviada', 'lida', 'respondida', 'arquivada')),
  anexos TEXT,
  FOREIGN KEY (remetente_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (destinatario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de logs de acesso
CREATE TABLE IF NOT EXISTS logs_acesso (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ip TEXT,
  dispositivo TEXT,
  acao TEXT NOT NULL,
  status TEXT NOT NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Índices para otimização de consultas
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_usuarios_tipo_perfil ON usuarios(tipo_perfil);
CREATE INDEX IF NOT EXISTS idx_vinculos_clinica_profissional ON vinculos_clinica_profissional(clinica_id, profissional_id);
CREATE INDEX IF NOT EXISTS idx_vinculos_profissional_paciente ON vinculos_profissional_paciente(profissional_id, paciente_id);
CREATE INDEX IF NOT EXISTS idx_sessoes_profissional ON sessoes(profissional_id);
CREATE INDEX IF NOT EXISTS idx_sessoes_paciente ON sessoes(paciente_id);
CREATE INDEX IF NOT EXISTS idx_atividades_paciente ON atividades(paciente_id);
CREATE INDEX IF NOT EXISTS idx_comunicacoes_remetente ON comunicacoes(remetente_id);
CREATE INDEX IF NOT EXISTS idx_comunicacoes_destinatario ON comunicacoes(destinatario_id);
