# TEAconecta - Versão Offline

Este é o frontend do TEAconecta em versão offline, que permite visualizar e testar todas as funcionalidades da plataforma sem necessidade de conexão com o backend.

## Sobre o TEAconecta

O TEAconecta é uma plataforma digital desenvolvida para facilitar o acompanhamento terapêutico de crianças com Transtorno do Espectro Autista (TEA). A plataforma conecta profissionais, pacientes e responsáveis, permitindo:

- Prescrição e acompanhamento de atividades terapêuticas
- Comunicação direta entre profissionais e responsáveis
- Agendamento e registro de sessões
- Captura de áudio e imagens durante atendimentos
- Geração de relatórios de progresso

## Versão Offline

Esta versão foi criada para demonstração e testes, permitindo explorar a interface e o fluxo de trabalho sem necessidade de um servidor backend. Todas as ações são simuladas localmente.

## Como usar

1. Abra o arquivo `src/login.html` em seu navegador
2. Use qualquer email e senha para fazer login (os campos já estarão preenchidos)
3. Explore as diferentes abas e funcionalidades
4. Teste a criação de atividades, mensagens e agendamentos
5. Experimente o fluxo de atendimento com gravação de áudio e captura de fotos

## Estrutura de arquivos

- `src/login.html` - Página de login
- `src/cadastro.html` - Página de cadastro
- `src/index.html` - Dashboard principal com todas as funcionalidades
- `src/js/` - Scripts JavaScript
- `src/css/` - Estilos CSS
- `src/assets/` - Imagens e recursos visuais

## Funcionalidades disponíveis

- **Dashboard**: Visão geral de atividades, comunicações e sessões
- **Atividades**: Criação e visualização de atividades terapêuticas
- **Comunicação**: Troca de mensagens entre profissionais e responsáveis
- **Sessões**: Agendamento e gerenciamento de atendimentos
- **Atendimento**: Registro de sessões com captura de áudio e fotos
- **Pacientes**: Visualização de lista de pacientes (em desenvolvimento)
- **Relatórios**: Geração de relatórios de progresso (em desenvolvimento)

## Observações

Esta é uma versão de demonstração com dados simulados. Para uma implementação completa, é necessário integrar com o backend TEAconecta SQLite.
