// Script para a página de login - versão offline
document.addEventListener('DOMContentLoaded', function() {
    console.log('[LOGIN] Página de login carregada - VERSÃO OFFLINE');
    
    // Configurar formulário de login
    const loginForm = document.getElementById('login-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            console.log('[LOGIN] Formulário de login submetido - VERSÃO OFFLINE');
            
            // Obter dados do formulário
            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;
            
            // Validar formulário
            if (!email || !senha) {
                console.log('[LOGIN] Campos obrigatórios não preenchidos');
                window.utils.showNotification('Por favor, preencha todos os campos', 'error');
                return;
            }
            
            try {
                console.log('[LOGIN] Simulando autenticação do usuário:', email);
                
                // Mostrar indicador de carregamento
                const submitButton = loginForm.querySelector('button[type="submit"]');
                const originalButtonText = submitButton.textContent;
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="material-icons spinning">refresh</span> Autenticando...';
                
                // Simular atraso de rede (para experiência mais realista)
                await new Promise(resolve => setTimeout(resolve, 1000));
                
                // Simular login bem-sucedido
                await window.api.auth.login(email, senha);
                
                console.log('[LOGIN] Login simulado bem-sucedido, redirecionando para a página principal');
                
                // Redirecionar para a página principal
                window.location.href = 'index.html';
                
            } catch (error) {
                console.error('[LOGIN] Erro no login simulado:', error);
                
                // Restaurar botão
                submitButton.disabled = false;
                submitButton.textContent = originalButtonText;
                
                // Na versão offline, não deveria ocorrer erro, mas mantemos o tratamento por completude
                window.utils.showNotification('Falha no login simulado. Tente novamente.', 'error');
            }
        });
    }
    
    // Configurar link de esqueceu a senha
    const forgotPasswordLink = document.getElementById('forgot-password');
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('[LOGIN] Link de esqueceu a senha clicado');
            window.utils.showNotification('Funcionalidade de recuperação de senha em desenvolvimento', 'info');
        });
    }
    
    // Configurar botão de fechar notificação
    const notificationClose = document.getElementById('notification-close');
    if (notificationClose) {
        notificationClose.addEventListener('click', function() {
            document.getElementById('notification').classList.remove('show');
        });
    }
    
    // Preencher automaticamente o formulário na versão offline
    setTimeout(() => {
        const emailInput = document.getElementById('email');
        const senhaInput = document.getElementById('senha');
        
        if (emailInput && senhaInput) {
            emailInput.value = 'admin@teaconecta.com';
            senhaInput.value = 'admin123';
            
            // Destacar os campos preenchidos automaticamente
            emailInput.style.backgroundColor = '#f0f8ff';
            senhaInput.style.backgroundColor = '#f0f8ff';
            
            // Mostrar notificação informando que é uma versão offline
            window.utils.showNotification('Esta é uma versão offline com dados simulados. Clique em "Entrar" para acessar o sistema.', 'info');
        }
    }, 500);
});
