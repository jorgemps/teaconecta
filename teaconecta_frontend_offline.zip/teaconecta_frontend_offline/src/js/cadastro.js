// Script para a página de cadastro - versão offline
document.addEventListener('DOMContentLoaded', function() {
    console.log('[CADASTRO] Página de cadastro carregada - VERSÃO OFFLINE');
    
    // Configurar formulário de cadastro
    const cadastroForm = document.getElementById('cadastro-form');
    const tipoUsuarioSelect = document.getElementById('tipo_usuario');
    
    // Configurar seleção de tipo de usuário
    if (tipoUsuarioSelect) {
        tipoUsuarioSelect.addEventListener('change', function() {
            const tipoUsuario = this.value;
            console.log(`[CADASTRO] Tipo de usuário selecionado: ${tipoUsuario}`);
            
            // Mostrar campos específicos baseado no tipo de usuário
            window.utils.showProfileSpecificFields(tipoUsuario);
        });
    }
    
    if (cadastroForm) {
        cadastroForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            console.log('[CADASTRO] Formulário de cadastro submetido - VERSÃO OFFLINE');
            
            // Validar formulário
            if (!window.utils.validateForm('cadastro-form')) {
                console.log('[CADASTRO] Validação do formulário falhou');
                window.utils.showNotification('Por favor, preencha todos os campos obrigatórios corretamente', 'error');
                return;
            }
            
            // Verificar se as senhas conferem
            const senha = document.getElementById('senha').value;
            const confirmarSenha = document.getElementById('confirmar_senha').value;
            
            if (senha !== confirmarSenha) {
                console.log('[CADASTRO] Senhas não conferem');
                window.utils.showNotification('As senhas não conferem', 'error');
                return;
            }
            
            try {
                console.log('[CADASTRO] Simulando cadastro de usuário');
                
                // Mostrar indicador de carregamento
                const submitButton = cadastroForm.querySelector('button[type="submit"]');
                const originalButtonText = submitButton.textContent;
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="material-icons spinning">refresh</span> Processando...';
                
                // Coletar dados do formulário
                const formData = new FormData(cadastroForm);
                const userData = {};
                
                for (const [key, value] of formData.entries()) {
                    userData[key] = value;
                }
                
                console.log('[CADASTRO] Dados do usuário:', userData);
                
                // Simular atraso de rede (para experiência mais realista)
                await new Promise(resolve => setTimeout(resolve, 1500));
                
                // Simular cadastro bem-sucedido
                await window.api.auth.register(userData);
                
                console.log('[CADASTRO] Cadastro simulado bem-sucedido, redirecionando para a página de login');
                
                // Mostrar mensagem de sucesso
                window.utils.showNotification('Cadastro realizado com sucesso! Redirecionando para a página de login...', 'success');
                
                // Redirecionar para a página de login após 2 segundos
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 2000);
                
            } catch (error) {
                console.error('[CADASTRO] Erro no cadastro simulado:', error);
                
                // Restaurar botão
                submitButton.disabled = false;
                submitButton.textContent = originalButtonText;
                
                // Na versão offline, não deveria ocorrer erro, mas mantemos o tratamento por completude
                window.utils.showNotification('Falha no cadastro simulado. Tente novamente.', 'error');
            }
        });
    }
    
    // Configurar botão de fechar notificação
    const notificationClose = document.getElementById('notification-close');
    if (notificationClose) {
        notificationClose.addEventListener('click', function() {
            document.getElementById('notification').classList.remove('show');
        });
    }
    
    // Mostrar notificação informando que é uma versão offline
    setTimeout(() => {
        window.utils.showNotification('Esta é uma versão offline com dados simulados. Você pode testar o cadastro com qualquer informação.', 'info');
    }, 500);
});
