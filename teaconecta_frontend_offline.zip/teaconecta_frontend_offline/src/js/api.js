// API simulada para versão offline
const API = (function() {
    // Dados simulados
    const mockData = {
        // Usuário atual
        currentUser: {
            id: 1,
            nome: 'Administrador',
            email: 'admin@teaconecta.com',
            tipo_perfil: 'ADMIN',
            data_criacao: '2025-05-01T10:00:00.000Z'
        },
        
        // Lista de usuários
        users: [
            {
                id: 1,
                nome: 'Administrador',
                email: 'admin@teaconecta.com',
                tipo_perfil: 'ADMIN',
                data_criacao: '2025-05-01T10:00:00.000Z'
            },
            {
                id: 2,
                nome: 'Dr. Carlos Silva',
                email: 'carlos.silva@teaconecta.com',
                tipo_perfil: 'PROFISSIONAL',
                especialidade: 'Terapia Ocupacional',
                data_criacao: '2025-05-02T10:00:00.000Z'
            },
            {
                id: 3,
                nome: 'Dra. Ana Ferreira',
                email: 'ana.ferreira@teaconecta.com',
                tipo_perfil: 'PROFISSIONAL',
                especialidade: 'Fonoaudiologia',
                data_criacao: '2025-05-02T11:00:00.000Z'
            },
            {
                id: 4,
                nome: 'Lucas Oliveira',
                email: 'lucas@email.com',
                tipo_perfil: 'PACIENTE',
                responsavel: 'Maria Oliveira',
                data_nascimento: '2018-03-15',
                data_criacao: '2025-05-03T10:00:00.000Z'
            },
            {
                id: 5,
                nome: 'Sofia Mendes',
                email: 'sofia@email.com',
                tipo_perfil: 'PACIENTE',
                responsavel: 'João Mendes',
                data_nascimento: '2017-07-22',
                data_criacao: '2025-05-03T11:00:00.000Z'
            },
            {
                id: 6,
                nome: 'Clínica Esperança',
                email: 'contato@clinicaesperanca.com',
                tipo_perfil: 'CLINICA',
                endereco: 'Rua das Flores, 123',
                telefone: '(11) 3456-7890',
                data_criacao: '2025-05-04T10:00:00.000Z'
            }
        ],
        
        // Lista de atividades
        activities: [
            {
                id: 1,
                titulo: 'Sequenciamento de Rotina Matinal',
                descricao: 'Atividade para trabalhar o sequenciamento da rotina matinal usando cartões visuais.',
                paciente_id: 4,
                paciente_nome: 'Lucas Oliveira',
                profissional_id: 2,
                profissional_nome: 'Dr. Carlos Silva',
                objetivos: 'Desenvolver autonomia na rotina matinal; Melhorar sequenciamento de ações.',
                recursos: 'Cartões visuais da rotina matinal; Velcro; Quadro de rotina.',
                status: 'EM_ANDAMENTO',
                data_criacao: '2025-05-10T14:30:00.000Z',
                data_atualizacao: '2025-05-12T10:15:00.000Z'
            },
            {
                id: 2,
                titulo: 'Exercícios de Sopro para Controle Respiratório',
                descricao: 'Conjunto de exercícios de sopro para melhorar o controle respiratório durante a fala.',
                paciente_id: 5,
                paciente_nome: 'Sofia Mendes',
                profissional_id: 3,
                profissional_nome: 'Dra. Ana Ferreira',
                objetivos: 'Melhorar controle respiratório; Aumentar tempo de fonação; Melhorar qualidade vocal.',
                recursos: 'Bolhas de sabão; Língua de sogra; Cata-vento; Apito.',
                status: 'PENDENTE',
                data_criacao: '2025-05-11T09:45:00.000Z',
                data_atualizacao: '2025-05-11T09:45:00.000Z'
            },
            {
                id: 3,
                titulo: 'Jogo de Associação de Emoções',
                descricao: 'Jogo para trabalhar o reconhecimento e nomeação de emoções básicas.',
                paciente_id: 4,
                paciente_nome: 'Lucas Oliveira',
                profissional_id: 2,
                profissional_nome: 'Dr. Carlos Silva',
                objetivos: 'Desenvolver reconhecimento de emoções; Ampliar vocabulário emocional; Melhorar expressão de sentimentos.',
                recursos: 'Cartões com expressões faciais; Espelho; Histórias sociais sobre emoções.',
                status: 'CONCLUIDA',
                data_criacao: '2025-05-08T15:20:00.000Z',
                data_atualizacao: '2025-05-15T16:30:00.000Z'
            }
        ],
        
        // Lista de comunicações
        communications: [
            {
                id: 1,
                remetente_id: 2,
                remetente_nome: 'Dr. Carlos Silva',
                destinatario_id: 4,
                destinatario_nome: 'Lucas Oliveira (Responsável)',
                assunto: 'Feedback da sessão de hoje',
                conteudo: 'Olá! Gostaria de compartilhar que o Lucas teve um ótimo desempenho na sessão de hoje. Conseguimos trabalhar o sequenciamento da rotina matinal e ele mostrou progresso significativo, conseguindo ordenar 4 de 5 cartões corretamente sem assistência. Recomendo continuar praticando em casa usando os cartões visuais que forneci. Na próxima sessão, vamos introduzir a rotina noturna. Alguma dúvida, estou à disposição!',
                status: 'LIDA',
                data_envio: '2025-05-15T17:30:00.000Z',
                data_leitura: '2025-05-15T19:45:00.000Z'
            },
            {
                id: 2,
                remetente_id: 3,
                remetente_nome: 'Dra. Ana Ferreira',
                destinatario_id: 5,
                destinatario_nome: 'Sofia Mendes (Responsável)',
                assunto: 'Exercícios para casa',
                conteudo: 'Prezado responsável, conforme conversamos na sessão de hoje, estou enviando os exercícios de sopro para serem praticados em casa. É importante realizar por 5-10 minutos diariamente, preferencialmente antes das refeições. Comece com as bolhas de sabão (3 minutos) e depois passe para o cata-vento (2 minutos). Registre o tempo máximo que Sofia consegue manter o cata-vento girando. Na próxima sessão, avaliaremos o progresso. Qualquer dificuldade, por favor, entre em contato.',
                status: 'NAO_LIDA',
                data_envio: '2025-05-16T14:20:00.000Z',
                data_leitura: null
            },
            {
                id: 3,
                remetente_id: 4,
                remetente_nome: 'Lucas Oliveira (Responsável)',
                destinatario_id: 2,
                destinatario_nome: 'Dr. Carlos Silva',
                assunto: 'Dúvida sobre cartões visuais',
                conteudo: 'Olá Dr. Carlos, estamos usando os cartões visuais em casa conforme orientado, mas notei que o Lucas ainda confunde a ordem entre escovar os dentes e tomar café da manhã. Tentamos explicar várias vezes, mas ele insiste que primeiro toma café e depois escova os dentes. Existe alguma estratégia específica que possamos usar para ajudá-lo a entender essa sequência corretamente? Agradeço a atenção!',
                status: 'NAO_LIDA',
                data_envio: '2025-05-17T08:15:00.000Z',
                data_leitura: null,
                anexo: 'foto_cartoes.jpg'
            }
        ]
    };
    
    // Simular atraso de rede
    function delay(ms = 500) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // Gerenciador de autenticação
    const authManager = {
        // Verificar se o usuário está autenticado (sempre retorna true na versão offline)
        isAuthenticated() {
            return true;
        },
        
        // Obter usuário atual
        getUser() {
            return mockData.currentUser;
        },
        
        // Salvar dados de autenticação (não faz nada na versão offline)
        setAuth(token, user) {
            console.log('[MOCK API] setAuth chamado com:', { token, user });
        },
        
        // Limpar dados de autenticação (não faz nada na versão offline)
        clearAuth() {
            console.log('[MOCK API] clearAuth chamado');
        }
    };
    
    // API de autenticação
    const auth = {
        // Login (sempre bem-sucedido na versão offline)
        async login(email, senha) {
            console.log('[MOCK API] Tentativa de login com:', { email });
            
            // Simular atraso de rede
            await delay();
            
            // Simular login bem-sucedido
            return {
                token: 'mock-jwt-token',
                usuario: mockData.currentUser
            };
        },
        
        // Registro (sempre bem-sucedido na versão offline)
        async register(userData) {
            console.log('[MOCK API] Tentativa de registro com:', userData);
            
            // Simular atraso de rede
            await delay();
            
            // Simular registro bem-sucedido
            return {
                message: 'Usuário registrado com sucesso',
                usuario: {
                    ...userData,
                    id: mockData.users.length + 1,
                    data_criacao: new Date().toISOString()
                }
            };
        },
        
        // Logout (sempre bem-sucedido na versão offline)
        async logout() {
            console.log('[MOCK API] Logout chamado');
            
            // Simular atraso de rede
            await delay();
            
            // Simular logout bem-sucedido
            return {
                message: 'Logout realizado com sucesso'
            };
        },
        
        // Obter perfil do usuário
        async getProfile() {
            console.log('[MOCK API] getProfile chamado');
            
            // Simular atraso de rede
            await delay();
            
            // Retornar perfil do usuário atual
            return mockData.currentUser;
        }
    };
    
    // API de usuários
    const users = {
        // Listar usuários
        async listUsers() {
            console.log('[MOCK API] listUsers chamado');
            
            // Simular atraso de rede
            await delay();
            
            // Retornar lista de usuários
            return mockData.users;
        },
        
        // Obter usuário por ID
        async getUser(id) {
            console.log(`[MOCK API] getUser chamado com ID: ${id}`);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar usuário pelo ID
            const user = mockData.users.find(user => user.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (!user) {
                throw {
                    status: 404,
                    message: `Usuário com ID ${id} não encontrado`
                };
            }
            
            // Retornar usuário
            return user;
        },
        
        // Atualizar usuário
        async updateUser(id, userData) {
            console.log(`[MOCK API] updateUser chamado com ID: ${id}`, userData);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar índice do usuário
            const userIndex = mockData.users.findIndex(user => user.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (userIndex === -1) {
                throw {
                    status: 404,
                    message: `Usuário com ID ${id} não encontrado`
                };
            }
            
            // Atualizar usuário
            mockData.users[userIndex] = {
                ...mockData.users[userIndex],
                ...userData,
                data_atualizacao: new Date().toISOString()
            };
            
            // Retornar usuário atualizado
            return mockData.users[userIndex];
        },
        
        // Excluir usuário
        async deleteUser(id) {
            console.log(`[MOCK API] deleteUser chamado com ID: ${id}`);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar índice do usuário
            const userIndex = mockData.users.findIndex(user => user.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (userIndex === -1) {
                throw {
                    status: 404,
                    message: `Usuário com ID ${id} não encontrado`
                };
            }
            
            // Remover usuário
            mockData.users.splice(userIndex, 1);
            
            // Retornar mensagem de sucesso
            return {
                message: `Usuário com ID ${id} excluído com sucesso`
            };
        }
    };
    
    // API de atividades
    const activities = {
        // Listar atividades
        async listActivities() {
            console.log('[MOCK API] listActivities chamado');
            
            // Simular atraso de rede
            await delay();
            
            // Retornar lista de atividades
            return mockData.activities;
        },
        
        // Obter atividade por ID
        async getActivity(id) {
            console.log(`[MOCK API] getActivity chamado com ID: ${id}`);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar atividade pelo ID
            const activity = mockData.activities.find(activity => activity.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (!activity) {
                throw {
                    status: 404,
                    message: `Atividade com ID ${id} não encontrada`
                };
            }
            
            // Retornar atividade
            return activity;
        },
        
        // Criar atividade
        async createActivity(activityData) {
            console.log('[MOCK API] createActivity chamado', activityData);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar paciente pelo ID
            const paciente = mockData.users.find(user => user.id === parseInt(activityData.paciente_id));
            
            // Criar nova atividade
            const newActivity = {
                ...activityData,
                id: mockData.activities.length + 1,
                paciente_nome: paciente ? paciente.nome : 'Paciente não encontrado',
                profissional_id: mockData.currentUser.id,
                profissional_nome: mockData.currentUser.nome,
                status: activityData.status || 'PENDENTE',
                data_criacao: new Date().toISOString(),
                data_atualizacao: new Date().toISOString()
            };
            
            // Adicionar à lista de atividades
            mockData.activities.push(newActivity);
            
            // Retornar atividade criada
            return newActivity;
        },
        
        // Atualizar atividade
        async updateActivity(id, activityData) {
            console.log(`[MOCK API] updateActivity chamado com ID: ${id}`, activityData);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar índice da atividade
            const activityIndex = mockData.activities.findIndex(activity => activity.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (activityIndex === -1) {
                throw {
                    status: 404,
                    message: `Atividade com ID ${id} não encontrada`
                };
            }
            
            // Atualizar atividade
            mockData.activities[activityIndex] = {
                ...mockData.activities[activityIndex],
                ...activityData,
                data_atualizacao: new Date().toISOString()
            };
            
            // Retornar atividade atualizada
            return mockData.activities[activityIndex];
        },
        
        // Excluir atividade
        async deleteActivity(id) {
            console.log(`[MOCK API] deleteActivity chamado com ID: ${id}`);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar índice da atividade
            const activityIndex = mockData.activities.findIndex(activity => activity.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (activityIndex === -1) {
                throw {
                    status: 404,
                    message: `Atividade com ID ${id} não encontrada`
                };
            }
            
            // Remover atividade
            mockData.activities.splice(activityIndex, 1);
            
            // Retornar mensagem de sucesso
            return {
                message: `Atividade com ID ${id} excluída com sucesso`
            };
        }
    };
    
    // API de comunicações
    const communications = {
        // Listar comunicações
        async listCommunications() {
            console.log('[MOCK API] listCommunications chamado');
            
            // Simular atraso de rede
            await delay();
            
            // Retornar lista de comunicações
            return mockData.communications;
        },
        
        // Obter comunicação por ID
        async getCommunication(id) {
            console.log(`[MOCK API] getCommunication chamado com ID: ${id}`);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar comunicação pelo ID
            const communication = mockData.communications.find(communication => communication.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (!communication) {
                throw {
                    status: 404,
                    message: `Comunicação com ID ${id} não encontrada`
                };
            }
            
            // Retornar comunicação
            return communication;
        },
        
        // Enviar comunicação
        async sendCommunication(communicationData) {
            console.log('[MOCK API] sendCommunication chamado', communicationData);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar destinatário pelo ID
            const destinatario = mockData.users.find(user => user.id === parseInt(communicationData.destinatario_id));
            
            // Criar nova comunicação
            const newCommunication = {
                ...communicationData,
                id: mockData.communications.length + 1,
                remetente_id: mockData.currentUser.id,
                remetente_nome: mockData.currentUser.nome,
                destinatario_nome: destinatario ? destinatario.nome : 'Destinatário não encontrado',
                status: 'NAO_LIDA',
                data_envio: new Date().toISOString(),
                data_leitura: null
            };
            
            // Adicionar à lista de comunicações
            mockData.communications.push(newCommunication);
            
            // Retornar comunicação criada
            return newCommunication;
        },
        
        // Atualizar status da comunicação
        async updateCommunicationStatus(id, status) {
            console.log(`[MOCK API] updateCommunicationStatus chamado com ID: ${id}, status: ${status}`);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar índice da comunicação
            const communicationIndex = mockData.communications.findIndex(communication => communication.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (communicationIndex === -1) {
                throw {
                    status: 404,
                    message: `Comunicação com ID ${id} não encontrada`
                };
            }
            
            // Atualizar status da comunicação
            mockData.communications[communicationIndex].status = status;
            
            // Se status for LIDA, atualizar data de leitura
            if (status === 'LIDA') {
                mockData.communications[communicationIndex].data_leitura = new Date().toISOString();
            }
            
            // Retornar comunicação atualizada
            return mockData.communications[communicationIndex];
        },
        
        // Excluir comunicação
        async deleteCommunication(id) {
            console.log(`[MOCK API] deleteCommunication chamado com ID: ${id}`);
            
            // Simular atraso de rede
            await delay();
            
            // Encontrar índice da comunicação
            const communicationIndex = mockData.communications.findIndex(communication => communication.id === parseInt(id));
            
            // Se não encontrar, lançar erro
            if (communicationIndex === -1) {
                throw {
                    status: 404,
                    message: `Comunicação com ID ${id} não encontrada`
                };
            }
            
            // Remover comunicação
            mockData.communications.splice(communicationIndex, 1);
            
            // Retornar mensagem de sucesso
            return {
                message: `Comunicação com ID ${id} excluída com sucesso`
            };
        }
    };
    
    // Expor a API
    return {
        authManager,
        auth,
        users,
        activities,
        communications
    };
})();

// Expor a API globalmente
window.api = API;

console.log('[MOCK API] API simulada inicializada com sucesso');
console.log('[MOCK API] Esta é uma versão offline com dados simulados');
console.log('[MOCK API] Não é necessário backend ou autenticação real');
