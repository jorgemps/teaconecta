// Funções utilitárias para o frontend
const Utils = (function() {
    // Formatar data para exibição
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
    }
    
    // Formatar data e hora para exibição
    function formatDateTime(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    // Atualizar data atual na interface
    function updateCurrentDate() {
        const currentDateElement = document.getElementById('current-date');
        if (currentDateElement) {
            const now = new Date();
            const options = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
            currentDateElement.textContent = now.toLocaleDateString('pt-BR', options);
        }
    }
    
    // Mostrar notificação
    function showNotification(message, type = 'info') {
        console.log(`[NOTIFICATION] ${type.toUpperCase()}: ${message}`);
        
        const notification = document.getElementById('notification');
        const notificationMessage = document.getElementById('notification-message');
        
        if (!notification || !notificationMessage) {
            console.error('[NOTIFICATION] Elementos de notificação não encontrados');
            alert(`${type.toUpperCase()}: ${message}`);
            return;
        }
        
        // Definir mensagem
        notificationMessage.textContent = message;
        
        // Remover classes de tipo anteriores
        notification.classList.remove('success', 'error', 'warning', 'info');
        
        // Adicionar classe de tipo
        notification.classList.add(type);
        
        // Mostrar notificação
        notification.classList.add('show');
        
        // Esconder notificação após 5 segundos
        setTimeout(() => {
            notification.classList.remove('show');
        }, 5000);
    }
    
    // Validar formulário
    function validateForm(formId) {
        console.log(`[VALIDATION] Validando formulário: ${formId}`);
        
        const form = document.getElementById(formId);
        if (!form) {
            console.error(`[VALIDATION] Formulário não encontrado: ${formId}`);
            return false;
        }
        
        let isValid = true;
        
        // Verificar campos obrigatórios
        const requiredFields = form.querySelectorAll('[required]');
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.classList.add('invalid');
                isValid = false;
                console.log(`[VALIDATION] Campo obrigatório não preenchido: ${field.id}`);
            } else {
                field.classList.remove('invalid');
            }
        });
        
        // Verificar campos de email
        const emailFields = form.querySelectorAll('input[type="email"]');
        emailFields.forEach(field => {
            if (field.value.trim() && !validateEmail(field.value.trim())) {
                field.classList.add('invalid');
                isValid = false;
                console.log(`[VALIDATION] Email inválido: ${field.id}`);
            }
        });
        
        // Verificar campos de senha
        const passwordFields = form.querySelectorAll('input[type="password"]');
        if (passwordFields.length > 1) {
            const password = passwordFields[0].value;
            const confirmPassword = passwordFields[1].value;
            
            if (password !== confirmPassword) {
                passwordFields[1].classList.add('invalid');
                isValid = false;
                console.log(`[VALIDATION] Senhas não conferem`);
            }
        }
        
        console.log(`[VALIDATION] Resultado da validação: ${isValid ? 'Válido' : 'Inválido'}`);
        return isValid;
    }
    
    // Validar email
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // Preencher select com opções
    function populateSelect(selectId, options, valueKey = 'id', textKey = 'nome') {
        console.log(`[SELECT] Preenchendo select: ${selectId}`);
        
        const select = document.getElementById(selectId);
        if (!select) {
            console.error(`[SELECT] Select não encontrado: ${selectId}`);
            return;
        }
        
        // Manter a primeira opção (geralmente "Selecione...")
        const firstOption = select.options[0];
        select.innerHTML = '';
        if (firstOption) {
            select.appendChild(firstOption);
        }
        
        // Adicionar opções
        options.forEach(option => {
            const optionElement = document.createElement('option');
            optionElement.value = option[valueKey];
            optionElement.textContent = option[textKey];
            select.appendChild(optionElement);
        });
        
        console.log(`[SELECT] Select preenchido com ${options.length} opções`);
    }
    
    // Mostrar campos específicos baseado no tipo de perfil
    function showProfileSpecificFields(profileType) {
        console.log(`[PROFILE] Mostrando campos específicos para: ${profileType}`);
        
        const camposEspecificos = document.getElementById('campos-especificos');
        if (!camposEspecificos) {
            console.error('[PROFILE] Container de campos específicos não encontrado');
            return;
        }
        
        // Limpar campos específicos
        camposEspecificos.innerHTML = '';
        
        // Adicionar campos específicos baseado no tipo de perfil
        switch (profileType) {
            case 'PACIENTE':
                camposEspecificos.innerHTML = `
                    <div class="form-group">
                        <label for="data_nascimento">Data de Nascimento</label>
                        <input type="date" id="data_nascimento" name="data_nascimento" required>
                    </div>
                    <div class="form-group">
                        <label for="responsavel">Nome do Responsável</label>
                        <input type="text" id="responsavel" name="responsavel" required>
                    </div>
                    <div class="form-group">
                        <label for="diagnostico">Diagnóstico</label>
                        <textarea id="diagnostico" name="diagnostico" rows="3"></textarea>
                    </div>
                `;
                break;
                
            case 'PROFISSIONAL':
                camposEspecificos.innerHTML = `
                    <div class="form-group">
                        <label for="especialidade">Especialidade</label>
                        <select id="especialidade" name="especialidade" required>
                            <option value="">Selecione uma especialidade...</option>
                            <option value="Terapia Ocupacional">Terapia Ocupacional</option>
                            <option value="Fonoaudiologia">Fonoaudiologia</option>
                            <option value="Psicologia">Psicologia</option>
                            <option value="Psicopedagogia">Psicopedagogia</option>
                            <option value="Fisioterapia">Fisioterapia</option>
                            <option value="Neurologia">Neurologia</option>
                            <option value="Psiquiatria">Psiquiatria</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="registro_profissional">Registro Profissional</label>
                        <input type="text" id="registro_profissional" name="registro_profissional" required>
                    </div>
                    <div class="form-group">
                        <label for="bio">Biografia Profissional</label>
                        <textarea id="bio" name="bio" rows="3"></textarea>
                    </div>
                `;
                break;
                
            case 'CLINICA':
                camposEspecificos.innerHTML = `
                    <div class="form-group">
                        <label for="cnpj">CNPJ</label>
                        <input type="text" id="cnpj" name="cnpj" required>
                    </div>
                    <div class="form-group">
                        <label for="endereco">Endereço</label>
                        <input type="text" id="endereco" name="endereco" required>
                    </div>
                    <div class="form-group">
                        <label for="telefone">Telefone</label>
                        <input type="tel" id="telefone" name="telefone" required>
                    </div>
                    <div class="form-group">
                        <label for="horario_funcionamento">Horário de Funcionamento</label>
                        <input type="text" id="horario_funcionamento" name="horario_funcionamento" placeholder="Ex: Segunda a Sexta, 8h às 18h">
                    </div>
                `;
                break;
                
            case 'ADMIN':
                camposEspecificos.innerHTML = `
                    <div class="form-group">
                        <label for="codigo_admin">Código de Administrador</label>
                        <input type="text" id="codigo_admin" name="codigo_admin" required>
                    </div>
                    <div class="form-group">
                        <label for="departamento">Departamento</label>
                        <input type="text" id="departamento" name="departamento">
                    </div>
                `;
                break;
                
            default:
                console.log('[PROFILE] Tipo de perfil não reconhecido');
                break;
        }
        
        console.log(`[PROFILE] Campos específicos atualizados para: ${profileType}`);
    }
    
    // Expor funções
    return {
        formatDate,
        formatDateTime,
        updateCurrentDate,
        showNotification,
        validateForm,
        validateEmail,
        populateSelect,
        showProfileSpecificFields
    };
})();

// Expor utilitários globalmente
window.utils = Utils;
