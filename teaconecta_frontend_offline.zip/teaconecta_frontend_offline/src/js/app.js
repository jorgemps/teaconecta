// Script principal da aplicação - versão offline
document.addEventListener('DOMContentLoaded', function() {
    console.log('[APP] Aplicação carregada - VERSÃO OFFLINE');
    
    // Atualizar data atual
    window.utils.updateCurrentDate();
    
    // Mostrar notificação de versão offline
    setTimeout(() => {
        window.utils.showNotification('Esta é uma versão offline com dados simulados. Todas as funcionalidades estão disponíveis para demonstração.', 'info');
    }, 1000);
    
    // Configurar navegação por abas
    const tabItems = document.querySelectorAll('.tab-item');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabItems.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetTab = this.getAttribute('data-tab');
            console.log(`[APP] Navegando para a aba: ${targetTab}`);
            
            // Remover classe ativa de todas as abas
            tabItems.forEach(item => item.classList.remove('active'));
            
            // Adicionar classe ativa à aba clicada
            this.classList.add('active');
            
            // Esconder todos os conteúdos de aba
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Mostrar conteúdo da aba selecionada
            const targetContent = document.getElementById(`${targetTab}-section`);
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });
    
    // Configurar modais
    function setupModal(modalId, openBtnIds, closeBtnIds, cancelBtnId, formId) {
        const modal = document.getElementById(modalId);
        if (!modal) return;
        
        // Abrir modal
        openBtnIds.forEach(btnId => {
            const openBtn = document.getElementById(btnId);
            if (openBtn) {
                openBtn.addEventListener('click', function() {
                    console.log(`[APP] Abrindo modal: ${modalId}`);
                    modal.style.display = 'block';
                });
            }
        });
        
        // Fechar modal
        closeBtnIds.forEach(btnId => {
            const closeBtn = document.getElementById(btnId);
            if (closeBtn) {
                closeBtn.addEventListener('click', function() {
                    console.log(`[APP] Fechando modal: ${modalId}`);
                    modal.style.display = 'none';
                });
            }
        });
        
        // Cancelar formulário
        const cancelBtn = document.getElementById(cancelBtnId);
        if (cancelBtn) {
            cancelBtn.addEventListener('click', function() {
                console.log(`[APP] Cancelando formulário: ${formId}`);
                modal.style.display = 'none';
            });
        }
        
        // Submeter formulário
        const form = document.getElementById(formId);
        if (form) {
            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                console.log(`[APP] Formulário submetido: ${formId}`);
                
                // Validar formulário
                if (!window.utils.validateForm(formId)) {
                    console.log(`[APP] Validação do formulário falhou: ${formId}`);
                    window.utils.showNotification('Por favor, preencha todos os campos obrigatórios corretamente', 'error');
                    return;
                }
                
                // Coletar dados do formulário
                const formData = new FormData(form);
                const formDataObj = {};
                
                for (const [key, value] of formData.entries()) {
                    formDataObj[key] = value;
                }
                
                console.log(`[APP] Dados do formulário: ${formId}`, formDataObj);
                
                try {
                    // Mostrar indicador de carregamento
                    const submitButton = form.querySelector('button[type="submit"]');
                    const originalButtonText = submitButton.textContent;
                    submitButton.disabled = true;
                    submitButton.innerHTML = '<span class="material-icons spinning">refresh</span> Processando...';
                    
                    // Simular atraso de rede
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    
                    // Processar formulário baseado no ID
                    let successMessage = '';
                    
                    switch (formId) {
                        case 'new-activity-form':
                            await window.api.activities.createActivity(formDataObj);
                            successMessage = 'Atividade criada com sucesso!';
                            break;
                            
                        case 'new-message-form':
                            await window.api.communications.sendCommunication(formDataObj);
                            successMessage = 'Mensagem enviada com sucesso!';
                            break;
                            
                        case 'new-session-form':
                            // Simulação de agendamento de sessão
                            successMessage = 'Sessão agendada com sucesso!';
                            break;
                            
                        default:
                            successMessage = 'Operação realizada com sucesso!';
                            break;
                    }
                    
                    // Restaurar botão
                    submitButton.disabled = false;
                    submitButton.textContent = originalButtonText;
                    
                    // Fechar modal
                    modal.style.display = 'none';
                    
                    // Mostrar mensagem de sucesso
                    window.utils.showNotification(successMessage, 'success');
                    
                    // Limpar formulário
                    form.reset();
                    
                } catch (error) {
                    console.error(`[APP] Erro ao processar formulário: ${formId}`, error);
                    
                    // Restaurar botão
                    submitButton.disabled = false;
                    submitButton.textContent = originalButtonText;
                    
                    // Mostrar mensagem de erro
                    window.utils.showNotification(`Erro ao processar formulário: ${error.message || 'Erro desconhecido'}`, 'error');
                }
            });
        }
    }
    
    // Configurar modal de nova atividade
    setupModal(
        'modal-new-activity',
        ['btn-new-activity', 'btn-new-activity-tab'],
        ['close-activity-modal'],
        'cancel-activity',
        'new-activity-form'
    );
    
    // Configurar modal de nova mensagem
    setupModal(
        'modal-new-message',
        ['btn-new-message', 'btn-new-message-tab'],
        ['close-message-modal'],
        'cancel-message',
        'new-message-form'
    );
    
    // Configurar modal de nova sessão
    setupModal(
        'modal-new-session',
        ['btn-new-session', 'btn-new-session-tab'],
        ['close-session-modal'],
        'cancel-session',
        'new-session-form'
    );
    
    // Configurar botões de ação na seção de atendimento
    const btnRecordAudio = document.getElementById('btn-record-audio');
    const btnTakePhoto = document.getElementById('btn-take-photo');
    const recordingStatus = document.getElementById('recording-status');
    const btnSaveDraft = document.getElementById('btn-save-draft');
    const btnFinishSession = document.getElementById('btn-finish-session');
    
    if (btnRecordAudio) {
        btnRecordAudio.addEventListener('click', function() {
            console.log('[APP] Iniciando gravação de áudio');
            
            // Simular gravação de áudio
            recordingStatus.style.display = 'flex';
            
            // Após 3 segundos, "parar" a gravação
            setTimeout(() => {
                console.log('[APP] Finalizando gravação de áudio');
                recordingStatus.style.display = 'none';
                
                // Adicionar novo áudio à lista
                const mediaList = document.getElementById('media-list');
                if (mediaList) {
                    const audioItem = document.createElement('div');
                    audioItem.className = 'audio-item';
                    audioItem.innerHTML = `
                        <span class="material-icons">audiotrack</span>
                        <span>Áudio 2 - 00:32</span>
                    `;
                    mediaList.appendChild(audioItem);
                }
                
                window.utils.showNotification('Áudio gravado com sucesso!', 'success');
            }, 3000);
        });
    }
    
    if (btnTakePhoto) {
        btnTakePhoto.addEventListener('click', function() {
            console.log('[APP] Capturando foto');
            
            // Simular captura de foto
            setTimeout(() => {
                // Adicionar nova foto à lista
                const mediaList = document.getElementById('media-list');
                if (mediaList) {
                    const photoItem = document.createElement('div');
                    photoItem.className = 'photo-item';
                    photoItem.innerHTML = `
                        <img src="assets/atividade-exemplo.jpg" alt="Foto da atividade">
                        <span>Foto 2 - Progresso na atividade</span>
                    `;
                    mediaList.appendChild(photoItem);
                }
                
                window.utils.showNotification('Foto capturada com sucesso!', 'success');
            }, 1000);
        });
    }
    
    if (btnSaveDraft) {
        btnSaveDraft.addEventListener('click', function() {
            console.log('[APP] Salvando rascunho da sessão');
            
            // Simular salvamento de rascunho
            setTimeout(() => {
                window.utils.showNotification('Rascunho salvo com sucesso!', 'success');
            }, 1000);
        });
    }
    
    if (btnFinishSession) {
        btnFinishSession.addEventListener('click', function() {
            console.log('[APP] Finalizando sessão');
            
            // Simular finalização de sessão
            setTimeout(() => {
                window.utils.showNotification('Sessão finalizada com sucesso! Relatório gerado e enviado ao responsável.', 'success');
                
                // Redirecionar para o dashboard após 2 segundos
                setTimeout(() => {
                    // Ativar a aba de dashboard
                    const dashboardTab = document.querySelector('.tab-item[data-tab="dashboard"]');
                    if (dashboardTab) {
                        dashboardTab.click();
                    }
                }, 2000);
            }, 1500);
        });
    }
    
    // Configurar botão de fechar notificação
    const notificationClose = document.getElementById('notification-close');
    if (notificationClose) {
        notificationClose.addEventListener('click', function() {
            document.getElementById('notification').classList.remove('show');
        });
    }
    
    // Configurar botões de ação nos cards
    document.querySelectorAll('.activity-actions .btn-icon, .session-actions .btn-outline').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.querySelector('.material-icons').textContent;
            console.log(`[APP] Ação de card clicada: ${action}`);
            
            switch (action) {
                case 'visibility':
                    window.utils.showNotification('Visualizando detalhes da atividade...', 'info');
                    break;
                    
                case 'edit':
                    window.utils.showNotification('Editando item...', 'info');
                    break;
                    
                case 'videocam':
                    // Ativar a aba de atendimento
                    const atendimentoTab = document.querySelector('.tab-item[data-tab="atendimento"]');
                    if (atendimentoTab) {
                        atendimentoTab.click();
                    }
                    break;
                    
                default:
                    window.utils.showNotification('Ação em desenvolvimento', 'info');
                    break;
            }
        });
    });
    
    // Configurar cards de mensagem para abrir detalhes
    document.querySelectorAll('.message-card').forEach(card => {
        card.addEventListener('click', function() {
            const sender = this.querySelector('.message-header h3').textContent;
            console.log(`[APP] Mensagem clicada: ${sender}`);
            
            window.utils.showNotification(`Visualizando mensagem de ${sender}`, 'info');
            
            // Marcar como lida se estiver não lida
            if (this.classList.contains('unread')) {
                this.classList.remove('unread');
            }
        });
    });
    
    // Configurar botões de notificação e configurações
    const btnNotifications = document.getElementById('btn-notifications');
    const btnSettings = document.getElementById('btn-settings');
    
    if (btnNotifications) {
        btnNotifications.addEventListener('click', function() {
            console.log('[APP] Botão de notificações clicado');
            window.utils.showNotification('Notificações em desenvolvimento', 'info');
        });
    }
    
    if (btnSettings) {
        btnSettings.addEventListener('click', function() {
            console.log('[APP] Botão de configurações clicado');
            window.utils.showNotification('Configurações em desenvolvimento', 'info');
        });
    }
});
